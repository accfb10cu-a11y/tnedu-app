export type Role = 'user' | 'admin';

export type SubmissionStatus = 'pending' | 'approved' | 'rejected';

export interface UserProfile {
  id: string;
  email: string;
  full_name: string;
  role: Role;
  is_locked: boolean;
  created_at: string;
  password?: string;
  submissions_count?: number;
  extra_spins?: number; // Số lượt lắc quà admin tặng thêm
  last_spin_date?: string; // YYYY-MM-DD
  spins_used_today?: number; // Số lượt đã lắc trong ngày
}

export interface SubmissionFile {
  name: string;
  size: number;
  type: string;
  url: string; // Storage URL or base64 DataURL
  path?: string; // Supabase storage path
}

export interface Submission {
  id: string;
  user_id: string;
  user_name: string;
  user_email: string;
  title: string;
  content: string;
  link_url?: string;
  file?: SubmissionFile;
  status: SubmissionStatus;
  admin_feedback?: string;
  reviewed_by?: string;
  reviewed_at?: string;
  created_at: string;
  updated_at: string;
}

export interface SystemSettings {
  is_maintenance: boolean;
  maintenance_message: string;
  allow_new_submissions: boolean;
  max_file_size_mb: number;
  allowed_file_types: string;
}

export interface SupabaseConfig {
  url: string;
  anonKey: string;
  isConnected: boolean;
}

export interface LuckyGift {
  id: string;
  name: string;
  amount: number; // Số tiền VNĐ
  probability: number; // Tỉ lệ (%)
  is_active: boolean; // Bật/Tắt quà
  color?: string;
  description?: string;
}
