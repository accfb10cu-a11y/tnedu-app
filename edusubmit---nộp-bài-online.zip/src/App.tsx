import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { SubmitForm } from './components/SubmitForm';
import { SubmissionList } from './components/SubmissionList';
import { AuthModal } from './components/AuthModal';
import { CelebrationOverlay } from './components/CelebrationOverlay';
import { MaintenanceNotice } from './components/MaintenanceNotice';
import { AdminPortal } from './components/admin/AdminPortal';
import { LuckyGiftBox } from './components/LuckyGiftBox';
import { UserProfile, SystemSettings } from './types';
import { dbService } from './services/db';
import { 
  GraduationCap, 
  Send, 
  Clock, 
  Sparkles, 
  ArrowRight,
  Lock
} from 'lucide-react';

export default function App() {
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [activeTab, setActiveTab] = useState<'submit' | 'history'>('submit');
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [celebratingUser, setCelebratingUser] = useState<UserProfile | null>(null);
  const [settings, setSettings] = useState<SystemSettings>({
    is_maintenance: false,
    maintenance_message: '',
    allow_new_submissions: true,
    max_file_size_mb: 25,
    allowed_file_types: 'pdf,docx,zip,rar,png,jpg,jpeg',
  });
  const [currentHash, setCurrentHash] = useState(window.location.hash);

  // Sync Hash changes with interval fallback for iframes
  useEffect(() => {
    const handleHashChange = () => {
      setCurrentHash(window.location.hash);
    };
    window.addEventListener('hashchange', handleHashChange);
    window.addEventListener('popstate', handleHashChange);
    const timer = setInterval(() => {
      if (window.location.hash !== currentHash) {
        setCurrentHash(window.location.hash);
      }
    }, 200);
    return () => {
      window.removeEventListener('hashchange', handleHashChange);
      window.removeEventListener('popstate', handleHashChange);
      clearInterval(timer);
    };
  }, [currentHash]);

  // Fetch initial session & settings
  useEffect(() => {
    document.title = 'TNedu - Nộp Bài Online';
    const user = dbService.getCurrentUser();
    setCurrentUser(user);

    dbService.getSystemSettings().then((s) => {
      setSettings(s);
    });
  }, []);

  const handleLoginSuccess = (user: UserProfile) => {
    setCurrentUser(user);
    // Show congratulatory screen for 3 seconds as required
    setCelebratingUser(user);
  };

  const handleLogout = async () => {
    await dbService.logout();
    setCurrentUser(null);
    window.location.hash = '';
    setCurrentHash('');
  };

  // Check if current view is Admin route (matches #adminbas, #/adminbas, #admin, etc.)
  const isAdminRoute = 
    currentHash.toLowerCase().includes('admin') ||
    (typeof window !== 'undefined' && (
      window.location.hash.toLowerCase().includes('admin') ||
      window.location.pathname.toLowerCase().includes('admin')
    ));

  // If URL hash matches admin route, render the isolated Admin Portal
  if (isAdminRoute) {
    return (
      <AdminPortal
        currentUser={currentUser}
        onLogout={handleLogout}
        onBackToMemberArea={() => {
          window.location.hash = '';
          setCurrentHash('');
        }}
        onLoginAsAdmin={(adminUser) => {
          setCurrentUser(adminUser);
        }}
      />
    );
  }

  // If System is under maintenance and current user is not Admin, show Maintenance Screen
  const isMaintenanceActive = settings.is_maintenance && currentUser?.role !== 'admin';

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col font-sans selection:bg-emerald-100 selection:text-emerald-900">
      {/* 3-Second Celebration Overlay after Login */}
      {celebratingUser && (
        <CelebrationOverlay
          user={celebratingUser}
          onComplete={() => {
            const role = celebratingUser.role;
            setCelebratingUser(null);
            if (role === 'admin') {
              window.location.hash = '#adminbas';
              setCurrentHash('#adminbas');
            } else {
              setActiveTab('submit');
            }
          }}
        />
      )}

      {/* Main Navbar */}
      <Navbar
        user={currentUser}
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        onLogout={handleLogout}
        onOpenAuth={() => setAuthModalOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        {isMaintenanceActive ? (
          <MaintenanceNotice
            settings={settings}
            onAdminLogin={() => {
              window.location.hash = '#admin';
            }}
          />
        ) : !currentUser ? (
          /* Guest Landing / Welcome Hero */
          <div className="py-6 sm:py-12 space-y-12 max-w-5xl mx-auto">
            <div className="text-center space-y-5">
              <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-100/90 text-emerald-800 text-xs font-bold border border-emerald-300 shadow-xs">
                <Sparkles className="w-4 h-4 text-emerald-600" />
                <span>TNedu • Nền tảng Nộp bài Trực tuyến Thế hệ mới</span>
              </div>

              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-slate-900 tracking-tight leading-tight">
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-600 to-teal-600">TNedu:</span> Nộp Bài Nhanh Chóng,{' '}
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-600 to-teal-500">
                  Bảo Mật & Chuẩn Xác
                </span>
              </h1>

              <p className="max-w-2xl mx-auto text-base sm:text-lg text-slate-600 leading-relaxed">
                Hệ thống nộp bài tập trực tuyến hỗ trợ liên kết dự án, tải tệp tin dung lượng lớn,
                theo dõi trạng thái phê duyệt và phản hồi từ giảng viên theo thời gian thực.
              </p>

              <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-4">
                <button
                  onClick={() => setAuthModalOpen(true)}
                  className="w-full sm:w-auto px-8 py-4 bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white font-bold rounded-2xl shadow-xl shadow-emerald-600/30 transition-all flex items-center justify-center gap-2 cursor-pointer text-base hover:scale-102"
                >
                  <span>Bắt đầu Nộp bài ngay</span>
                  <ArrowRight className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Feature Cards Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-6">
              <div className="bg-white p-6 rounded-3xl border border-emerald-100/80 shadow-xs hover:shadow-md transition-shadow">
                <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center mb-4">
                  <Send className="w-6 h-6" />
                </div>
                <h3 className="font-bold text-slate-800 text-base mb-1">
                  Đa dạng hình thức nộp
                </h3>
                <p className="text-xs text-slate-500 leading-relaxed">
                  Nhập tiêu đề, nội dung thuyết minh, đính kèm đường link và tải tệp/hình ảnh dung lượng tới 25MB.
                </p>
              </div>

              <div className="bg-white p-6 rounded-3xl border border-emerald-100/80 shadow-xs hover:shadow-md transition-shadow">
                <div className="w-12 h-12 rounded-2xl bg-teal-50 text-teal-600 flex items-center justify-center mb-4">
                  <Clock className="w-6 h-6" />
                </div>
                <h3 className="font-bold text-slate-800 text-base mb-1">
                  Theo dõi trạng thái tức thì
                </h3>
                <p className="text-xs text-slate-500 leading-relaxed">
                  Trạng thái Chờ duyệt, Đã duyệt hoặc Từ chối kèm lý do phản hồi chi tiết từ giảng viên để dễ dàng chỉnh sửa.
                </p>
              </div>

              <div className="bg-white p-6 rounded-3xl border border-emerald-100/80 shadow-xs hover:shadow-md transition-shadow">
                <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-700 flex items-center justify-center mb-4">
                  <Lock className="w-6 h-6" />
                </div>
                <h3 className="font-bold text-slate-800 text-base mb-1">
                  Bảo mật Private Storage & RLS
                </h3>
                <p className="text-xs text-slate-500 leading-relaxed">
                  Mỗi học viên chỉ xem và tải tệp của chính mình. Phân quyền chặt chẽ giữa Học viên và Ban Quản Trị.
                </p>
              </div>
            </div>
          </div>
        ) : activeTab === 'submit' ? (
          <SubmitForm
            user={currentUser}
            onSubmittedSuccess={() => setActiveTab('history')}
          />
        ) : (
          <SubmissionList
            user={currentUser}
            onGoToSubmit={() => setActiveTab('submit')}
          />
        )}
      </main>

      {/* Lucky Gift Box at bottom of the webpage */}
      <LuckyGiftBox />

      {/* Footer */}
      <footer className="mt-auto border-t border-emerald-100/80 bg-white/70 py-6 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-3 text-center sm:text-left">
          <div className="flex items-center gap-2">
            <GraduationCap className="w-4 h-4 text-emerald-600" />
            <span className="font-extrabold text-slate-800">TNedu</span>
            <span>• Hệ thống Nộp Bài Trực Tuyến TNedu</span>
          </div>

          <div className="text-slate-400 text-[11px]">
            Nền tảng bảo mật & quản lý học tập TNedu
          </div>
        </div>
      </footer>

      {/* Auth Modal */}
      <AuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        onSuccess={handleLoginSuccess}
      />
    </div>
  );
}
