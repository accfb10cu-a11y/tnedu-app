import { UserProfile, Submission, SystemSettings, Role, SubmissionStatus, SubmissionFile, LuckyGift } from '../types';
import { getSupabaseClient } from '../lib/supabase';

// Local Storage Keys for Persistent Local Engine
const USERS_KEY = 'edusubmit_local_users';
const PASSWORDS_KEY = 'edusubmit_local_passwords';
const SUBMISSIONS_KEY = 'edusubmit_local_submissions';
const SETTINGS_KEY = 'edusubmit_local_settings';
const CURRENT_USER_KEY = 'edusubmit_current_user';
const LUCKY_GIFTS_KEY = 'tnedu_lucky_gifts';

const defaultLuckyGifts: LuckyGift[] = [
  {
    id: 'gift_1',
    name: 'Lì xì 10.000đ May Mắn',
    amount: 10000,
    probability: 40,
    is_active: true,
    color: '#10b981',
    description: 'Chúc bạn học tập tiến bộ và gặt hái nhiều điểm tốt!',
  },
  {
    id: 'gift_2',
    name: 'Lì xì 20.000đ Tài Lộc',
    amount: 20000,
    probability: 30,
    is_active: true,
    color: '#06b6d4',
    description: 'Vạn sự hanh thông, bài nộp đạt điểm tối đa!',
  },
  {
    id: 'gift_3',
    name: 'Lì xì 50.000đ Phát Tài',
    amount: 50000,
    probability: 18,
    is_active: true,
    color: '#f59e0b',
    description: 'Tài năng bừng sáng, nỗ lực luôn được đền đáp!',
  },
  {
    id: 'gift_4',
    name: 'Lì xì 100.000đ Thịnh Vượng',
    amount: 100000,
    probability: 10,
    is_active: true,
    color: '#ec4899',
    description: 'Chúc mừng bạn trúng phần quà lớn từ TNedu!',
  },
  {
    id: 'gift_5',
    name: 'Jackpot Siêu Khủng 200.000đ',
    amount: 200000,
    probability: 2,
    is_active: true,
    color: '#8b5cf6',
    description: 'Vô cùng may mắn! Giải đặc biệt hôm nay thuộc về bạn!',
  },
];

// Seed Initial Mock Data if storage is empty
const seedInitialData = () => {
  if (!localStorage.getItem(USERS_KEY)) {
    const initialUsers: UserProfile[] = [
      {
        id: 'usr_admin_001',
        email: 'admin@tnedu.vn',
        full_name: 'Quản Trị Viên TNedu',
        role: 'admin',
        is_locked: false,
        created_at: new Date(Date.now() - 86400000 * 30).toISOString(),
      },
      {
        id: 'usr_student_001',
        email: 'duongma@gmail.com',
        full_name: 'Dương Hào Ma',
        role: 'user',
        is_locked: false,
        created_at: new Date(Date.now() - 86400000 * 10).toISOString(),
      },
      {
        id: 'usr_student_002',
        email: 'tranthibich@gmail.com',
        full_name: 'Trần Thị Bích',
        role: 'user',
        is_locked: false,
        created_at: new Date(Date.now() - 86400000 * 5).toISOString(),
      },
    ];

    const initialPasswords: Record<string, string> = {
      'admin@tnedu.vn': 'admin123',
      'duongma@gmail.com': '123456',
      'tranthibich@gmail.com': '123456',
    };

    localStorage.setItem(USERS_KEY, JSON.stringify(initialUsers));
    localStorage.setItem(PASSWORDS_KEY, JSON.stringify(initialPasswords));
  }

  if (!localStorage.getItem(SUBMISSIONS_KEY)) {
    const initialSubmissions: Submission[] = [
      {
        id: 'sub_001',
        user_id: 'usr_student_001',
        user_name: 'Dương Hào Ma',
        user_email: 'duongma@gmail.com',
        title: 'Báo cáo Đồ án Cuối kỳ - Ứng dụng Quản lý Thư viện',
        content: 'Em xin gửi đồ án môn Công nghệ phần mềm. Hệ thống bao gồm module phân loại sách, mượn trả và quản lý hội viên.',
        link_url: 'https://example.com/baocao-doan-cuoiky',
        status: 'approved',
        admin_feedback: 'Bài nộp rất đầy đủ, cấu trúc mã nguồn rõ ràng, có video demo đính kèm rất tốt. Đạt điểm A.',
        reviewed_by: 'Quản Trị Viên Hệ Thống',
        reviewed_at: new Date(Date.now() - 86400000 * 2).toISOString(),
        created_at: new Date(Date.now() - 86400000 * 4).toISOString(),
        updated_at: new Date(Date.now() - 86400000 * 2).toISOString(),
      },
      {
        id: 'sub_002',
        user_id: 'usr_student_001',
        user_name: 'Dương Hào Ma',
        user_email: 'duongma@gmail.com',
        title: 'Bài tập Tuần 5 - Thiết kế Cơ sở Dữ liệu SQL',
        content: 'Kèm theo file sơ đồ ERD và script tạo bảng với các ràng buộc khóa ngoại đầy đủ.',
        status: 'rejected',
        admin_feedback: 'Thiếu ràng buộc khoá ngoại ON DELETE CASCADE ở bảng OrderDetails và chưa chuẩn hoá đạt mức 3NF. Vui lòng bổ sung và nộp lại trước thứ Sáu.',
        reviewed_by: 'Quản Trị Viên Hệ Thống',
        reviewed_at: new Date(Date.now() - 86400000 * 1).toISOString(),
        created_at: new Date(Date.now() - 86400000 * 3).toISOString(),
        updated_at: new Date(Date.now() - 86400000 * 1).toISOString(),
      },
      {
        id: 'sub_003',
        user_id: 'usr_student_002',
        user_name: 'Trần Thị Bích',
        user_email: 'tranthibich@gmail.com',
        title: 'Bài tập lớn: Thiết kế Giao diện UI/UX Mobile App',
        content: 'Bài nộp thiết kế ứng dụng giao đồ ăn nhanh GreenFood gồm 18 screens trên Figma cùng Prototype tương tác.',
        link_url: 'https://www.figma.com/design/example-prototype',
        status: 'pending',
        created_at: new Date(Date.now() - 3600000 * 5).toISOString(),
        updated_at: new Date(Date.now() - 3600000 * 5).toISOString(),
      },
    ];

    localStorage.setItem(SUBMISSIONS_KEY, JSON.stringify(initialSubmissions));
  }

  if (!localStorage.getItem(SETTINGS_KEY)) {
    const defaultSettings: SystemSettings = {
      is_maintenance: false,
      maintenance_message: 'Hệ thống đang bảo trì để nâng cấp cơ sở dữ liệu và bảo mật. Vui lòng quay lại sau.',
      allow_new_submissions: true,
      max_file_size_mb: 25,
      allowed_file_types: 'pdf,docx,zip,rar,png,jpg,jpeg',
    };
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(defaultSettings));
  }
};

// Initialize seed data immediately
seedInitialData();

// Always guarantee default admin and student accounts exist and are healthy
export const ensureAccounts = () => {
  let users: UserProfile[] = [];
  try {
    users = JSON.parse(localStorage.getItem(USERS_KEY) || '[]');
  } catch {
    users = [];
  }

  let passwords: Record<string, string> = {};
  try {
    passwords = JSON.parse(localStorage.getItem(PASSWORDS_KEY) || '{}');
  } catch {
    passwords = {};
  }

  // Migrate any old edusubmit admin accounts to tnedu
  users.forEach((u) => {
    if (u.email.toLowerCase() === 'admin@edusubmit.vn') {
      u.email = 'admin@tnedu.vn';
      u.full_name = 'Quản Trị Viên TNedu';
      u.role = 'admin';
      u.password = 'admin123';
      u.is_locked = false;
    }
  });

  // Ensure TNedu admin exists and is active
  const adminIndex = users.findIndex((u) => u.email.toLowerCase() === 'admin@tnedu.vn');
  if (adminIndex === -1) {
    users.unshift({
      id: 'usr_admin_001',
      email: 'admin@tnedu.vn',
      full_name: 'Quản Trị Viên TNedu',
      role: 'admin',
      is_locked: false,
      password: 'admin123',
      created_at: new Date(Date.now() - 86400000 * 30).toISOString(),
    });
  } else {
    users[adminIndex].email = 'admin@tnedu.vn';
    users[adminIndex].full_name = 'Quản Trị Viên TNedu';
    users[adminIndex].role = 'admin';
    users[adminIndex].is_locked = false;
    users[adminIndex].password = 'admin123';
  }
  passwords['admin@tnedu.vn'] = 'admin123';

  // Ensure student Dương Hào Ma exists and migrate old test student if present
  const studentIndex = users.findIndex((u) => u.email.toLowerCase() === 'duongma@gmail.com');
  if (studentIndex === -1) {
    // Check if previous sample student exists to update
    const oldStudentIndex = users.findIndex((u) => u.email.toLowerCase() === 'nguyenvanan@gmail.com');
    if (oldStudentIndex !== -1) {
      users[oldStudentIndex].email = 'duongma@gmail.com';
      users[oldStudentIndex].full_name = 'Dương Hào Ma';
      users[oldStudentIndex].password = '123456';
    } else {
      users.push({
        id: 'usr_student_001',
        email: 'duongma@gmail.com',
        full_name: 'Dương Hào Ma',
        role: 'user',
        is_locked: false,
        password: '123456',
        created_at: new Date(Date.now() - 86400000 * 10).toISOString(),
      });
    }
  } else {
    users[studentIndex].full_name = 'Dương Hào Ma';
    users[studentIndex].password = '123456';
  }
  passwords['duongma@gmail.com'] = '123456';

  // Also update any existing submissions tied to previous sample student
  const rawSubs = localStorage.getItem(SUBMISSIONS_KEY);
  if (rawSubs) {
    try {
      const subs = JSON.parse(rawSubs);
      let updated = false;
      subs.forEach((s: any) => {
        if (s.user_email === 'nguyenvanan@gmail.com') {
          s.user_email = 'duongma@gmail.com';
          s.user_name = 'Dương Hào Ma';
          updated = true;
        }
      });
      if (updated) {
        localStorage.setItem(SUBMISSIONS_KEY, JSON.stringify(subs));
      }
    } catch {}
  }

  // Also update active session if it was logged in as the sample student
  const rawSession = localStorage.getItem(CURRENT_USER_KEY);
  if (rawSession) {
    try {
      const session = JSON.parse(rawSession);
      if (session.email === 'nguyenvanan@gmail.com') {
        session.email = 'duongma@gmail.com';
        session.full_name = 'Dương Hào Ma';
        localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(session));
      }
    } catch {}
  }

  localStorage.setItem(USERS_KEY, JSON.stringify(users));
  localStorage.setItem(PASSWORDS_KEY, JSON.stringify(passwords));
};

// Run guarantee check immediately
ensureAccounts();

export const dbService = {
  // Current Logged-in Session
  getCurrentUser(): UserProfile | null {
    const raw = localStorage.getItem(CURRENT_USER_KEY);
    if (!raw) return null;
    try {
      return JSON.parse(raw);
    } catch {
      return null;
    }
  },

  setCurrentUser(user: UserProfile | null) {
    if (user) {
      localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(user));
    } else {
      localStorage.removeItem(CURRENT_USER_KEY);
    }
  },

  // Auth Operations
  async register(fullName: string, email: string, password: string): Promise<UserProfile> {
    ensureAccounts();
    const cleanEmail = email.trim().toLowerCase();

    // Check existing accounts
    const users: UserProfile[] = JSON.parse(localStorage.getItem(USERS_KEY) || '[]');
    const existing = users.find((u) => u.email.toLowerCase() === cleanEmail);
    if (existing) {
      if (cleanEmail === 'admin@tnedu.vn') {
        throw new Error('Tài khoản Quản trị viên (admin@tnedu.vn) đã có sẵn! Vui lòng chọn tab "Đăng nhập" (Mật khẩu: admin123).');
      }
      throw new Error('Email này đã được đăng ký trong hệ thống. Vui lòng chuyển sang tab "Đăng nhập" để truy cập.');
    }

    const supabase = getSupabaseClient();
    if (supabase) {
      try {
        const { data, error } = await supabase.auth.signUp({
          email: cleanEmail,
          password,
          options: {
            data: {
              full_name: fullName.trim(),
            },
          },
        });

        if (!error && data?.user) {
          const role: Role = cleanEmail.includes('admin') ? 'admin' : 'user';
          const profile: UserProfile = {
            id: data.user.id,
            email: cleanEmail,
            full_name: fullName.trim(),
            role,
            is_locked: false,
            password,
            created_at: new Date().toISOString(),
          };

          try {
            await supabase.from('profiles').upsert([profile]).select();
          } catch {
            // ignore
          }
          return profile;
        }
      } catch (err: any) {
        console.warn('Supabase signUp error, continuing with local engine fallback:', err?.message);
      }
    }

    // Local Engine Fallback (Guaranteed to succeed)
    const newUser: UserProfile = {
      id: 'usr_' + Date.now().toString(36) + Math.random().toString(36).substring(2, 6),
      email: cleanEmail,
      full_name: fullName.trim(),
      role: cleanEmail.includes('admin') ? 'admin' : 'user',
      is_locked: false,
      password: password,
      created_at: new Date().toISOString(),
    };

    users.push(newUser);
    const passwords: Record<string, string> = JSON.parse(localStorage.getItem(PASSWORDS_KEY) || '{}');
    passwords[cleanEmail] = password;

    localStorage.setItem(USERS_KEY, JSON.stringify(users));
    localStorage.setItem(PASSWORDS_KEY, JSON.stringify(passwords));

    return newUser;
  },

  async login(email: string, password: string): Promise<UserProfile> {
    ensureAccounts();
    const cleanEmail = email.trim().toLowerCase();

    // Master Admin Bypass: guarantee admin login always works regardless of cloud state
    if (cleanEmail === 'admin@tnedu.vn' && password === 'admin123') {
      const adminUser: UserProfile = {
        id: 'usr_admin_001',
        email: 'admin@tnedu.vn',
        full_name: 'Quản Trị Viên TNedu',
        role: 'admin',
        is_locked: false,
        password: 'admin123',
        created_at: new Date(Date.now() - 86400000 * 30).toISOString(),
      };
      this.setCurrentUser(adminUser);
      return adminUser;
    }

    const supabase = getSupabaseClient();
    if (supabase) {
      try {
        const { data, error } = await supabase.auth.signInWithPassword({
          email: cleanEmail,
          password,
        });

        if (!error && data?.user) {
          const { data: profileData } = await supabase
            .from('profiles')
            .select('*')
            .eq('id', data.user.id)
            .single();

          if (profileData?.is_locked) {
            await supabase.auth.signOut();
            throw new Error('Tài khoản của bạn đã bị khóa bởi Quản trị viên. Vui lòng liên hệ hỗ trợ.');
          }

          const user: UserProfile = {
            id: data.user.id,
            email: cleanEmail,
            full_name: profileData?.full_name || cleanEmail.split('@')[0],
            role: profileData?.role || (cleanEmail.includes('admin') ? 'admin' : 'user'),
            is_locked: profileData?.is_locked || false,
            created_at: profileData?.created_at || new Date().toISOString(),
          };

          this.setCurrentUser(user);
          return user;
        }
      } catch (err: any) {
        // If Supabase locked the account, re-throw
        if (err?.message?.includes('khóa')) {
          throw err;
        }
        // Otherwise, continue to local storage check
        console.warn('Supabase login failed, checking local credentials fallback:', err?.message);
      }
    }

    // Local Engine Fallback
    const users: UserProfile[] = JSON.parse(localStorage.getItem(USERS_KEY) || '[]');
    const passwords: Record<string, string> = JSON.parse(localStorage.getItem(PASSWORDS_KEY) || '{}');

    const foundUser = users.find((u) => u.email.toLowerCase() === cleanEmail);
    if (!foundUser) {
      throw new Error('Tài khoản không tồn tại. Vui lòng kiểm tra lại email.');
    }

    const expectedPassword = passwords[cleanEmail] || foundUser.password || '123456';
    if (expectedPassword !== password) {
      throw new Error('Mật khẩu không chính xác.');
    }

    if (foundUser.is_locked) {
      throw new Error('Tài khoản của bạn đã bị khóa bởi Quản trị viên. Vui lòng liên hệ ban quản trị.');
    }

    this.setCurrentUser(foundUser);
    return foundUser;
  },

  async logout(): Promise<void> {
    const supabase = getSupabaseClient();
    if (supabase) {
      try {
        await supabase.auth.signOut();
      } catch {
        // ignore
      }
    }
    this.setCurrentUser(null);
  },

  // Submissions operations
  async createSubmission(
    submissionData: Omit<Submission, 'id' | 'status' | 'created_at' | 'updated_at'>
  ): Promise<Submission> {
    const supabase = getSupabaseClient();
    const newSub: Submission = {
      ...submissionData,
      id: 'sub_' + Date.now().toString(36) + Math.random().toString(36).substring(2, 6),
      status: 'pending',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };

    if (supabase) {
      const payload: any = {
        user_id: submissionData.user_id,
        user_name: submissionData.user_name,
        user_email: submissionData.user_email,
        title: submissionData.title,
        content: submissionData.content,
        link_url: submissionData.link_url || null,
        status: 'pending',
      };

      if (submissionData.file) {
        payload.file_name = submissionData.file.name;
        payload.file_size = submissionData.file.size;
        payload.file_type = submissionData.file.type;
        payload.file_url = submissionData.file.url;
        payload.file_path = submissionData.file.path || null;
      }

      const { data, error } = await supabase.from('submissions').insert([payload]).select().single();
      if (error) {
        console.warn('Supabase insert failed, fallback to local save:', error.message);
      } else if (data) {
        return {
          id: data.id,
          user_id: data.user_id,
          user_name: data.user_name,
          user_email: data.user_email,
          title: data.title,
          content: data.content,
          link_url: data.link_url,
          file: data.file_name
            ? {
                name: data.file_name,
                size: data.file_size,
                type: data.file_type,
                url: data.file_url,
                path: data.file_path,
              }
            : undefined,
          status: data.status,
          admin_feedback: data.admin_feedback,
          reviewed_by: data.reviewed_by,
          reviewed_at: data.reviewed_at,
          created_at: data.created_at,
          updated_at: data.updated_at,
        };
      }
    }

    // Save to local storage
    const submissions: Submission[] = JSON.parse(localStorage.getItem(SUBMISSIONS_KEY) || '[]');
    submissions.unshift(newSub);
    localStorage.setItem(SUBMISSIONS_KEY, JSON.stringify(submissions));
    return newSub;
  },

  async getUserSubmissions(userId: string): Promise<Submission[]> {
    const supabase = getSupabaseClient();
    if (supabase) {
      const { data, error } = await supabase
        .from('submissions')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false });

      if (!error && data) {
        return data.map((item) => ({
          id: item.id,
          user_id: item.user_id,
          user_name: item.user_name,
          user_email: item.user_email,
          title: item.title,
          content: item.content,
          link_url: item.link_url,
          file: item.file_name
            ? {
                name: item.file_name,
                size: item.file_size,
                type: item.file_type,
                url: item.file_url,
                path: item.file_path,
              }
            : undefined,
          status: item.status,
          admin_feedback: item.admin_feedback,
          reviewed_by: item.reviewed_by,
          reviewed_at: item.reviewed_at,
          created_at: item.created_at,
          updated_at: item.updated_at,
        }));
      }
    }

    // Local fallback: strictly filter by userId
    const submissions: Submission[] = JSON.parse(localStorage.getItem(SUBMISSIONS_KEY) || '[]');
    return submissions.filter((s) => s.user_id === userId);
  },

  async getAllSubmissions(): Promise<Submission[]> {
    const supabase = getSupabaseClient();
    if (supabase) {
      const { data, error } = await supabase
        .from('submissions')
        .select('*')
        .order('created_at', { ascending: false });

      if (!error && data) {
        return data.map((item) => ({
          id: item.id,
          user_id: item.user_id,
          user_name: item.user_name,
          user_email: item.user_email,
          title: item.title,
          content: item.content,
          link_url: item.link_url,
          file: item.file_name
            ? {
                name: item.file_name,
                size: item.file_size,
                type: item.file_type,
                url: item.file_url,
                path: item.file_path,
              }
            : undefined,
          status: item.status,
          admin_feedback: item.admin_feedback,
          reviewed_by: item.reviewed_by,
          reviewed_at: item.reviewed_at,
          created_at: item.created_at,
          updated_at: item.updated_at,
        }));
      }
    }

    const submissions: Submission[] = JSON.parse(localStorage.getItem(SUBMISSIONS_KEY) || '[]');
    return submissions;
  },

  async updateSubmissionStatus(
    submissionId: string,
    status: SubmissionStatus,
    feedback: string,
    adminName: string
  ): Promise<void> {
    if (status === 'rejected' && (!feedback || !feedback.trim())) {
      throw new Error('Bắt buộc phải nhập lý do khi từ chối bài nộp của học viên.');
    }

    const now = new Date().toISOString();
    const supabase = getSupabaseClient();

    if (supabase) {
      const { error } = await supabase
        .from('submissions')
        .update({
          status,
          admin_feedback: feedback.trim(),
          reviewed_by: adminName,
          reviewed_at: now,
          updated_at: now,
        })
        .eq('id', submissionId);

      if (error) {
        console.warn('Supabase update failed:', error.message);
      }
    }

    // Local update
    const submissions: Submission[] = JSON.parse(localStorage.getItem(SUBMISSIONS_KEY) || '[]');
    const index = submissions.findIndex((s) => s.id === submissionId);
    if (index !== -1) {
      submissions[index] = {
        ...submissions[index],
        status,
        admin_feedback: feedback.trim(),
        reviewed_by: adminName,
        reviewed_at: now,
        updated_at: now,
      };
      localStorage.setItem(SUBMISSIONS_KEY, JSON.stringify(submissions));
    }
  },

  async deleteSubmission(submissionId: string): Promise<void> {
    const supabase = getSupabaseClient();
    if (supabase) {
      await supabase.from('submissions').delete().eq('id', submissionId);
    }
    const submissions: Submission[] = JSON.parse(localStorage.getItem(SUBMISSIONS_KEY) || '[]');
    const filtered = submissions.filter((s) => s.id !== submissionId);
    localStorage.setItem(SUBMISSIONS_KEY, JSON.stringify(filtered));
  },

  // User Management for Admin
  async getAllUsers(): Promise<UserProfile[]> {
    const supabase = getSupabaseClient();
    let usersList: UserProfile[] = [];

    if (supabase) {
      const { data, error } = await supabase.from('profiles').select('*').order('created_at', { ascending: false });
      if (!error && data && data.length > 0) {
        usersList = data;
      }
    }

    if (usersList.length === 0) {
      usersList = JSON.parse(localStorage.getItem(USERS_KEY) || '[]');
    }

    const passwords: Record<string, string> = JSON.parse(localStorage.getItem(PASSWORDS_KEY) || '{}');
    const submissions = await this.getAllSubmissions();

    return usersList.map((user) => {
      const emailLower = user.email.toLowerCase();
      const userPassword = passwords[emailLower] || user.password || (emailLower.includes('admin') ? 'admin123' : '123456');
      return {
        ...user,
        password: userPassword,
        submissions_count: submissions.filter((s) => s.user_id === user.id).length,
      };
    });
  },

  async setUserLockStatus(userId: string, isLocked: boolean): Promise<void> {
    const supabase = getSupabaseClient();
    if (supabase) {
      await supabase.from('profiles').update({ is_locked: isLocked }).eq('id', userId);
    }

    const users: UserProfile[] = JSON.parse(localStorage.getItem(USERS_KEY) || '[]');
    const index = users.findIndex((u) => u.id === userId);
    if (index !== -1) {
      users[index].is_locked = isLocked;
      localStorage.setItem(USERS_KEY, JSON.stringify(users));
    }
  },

  async updateUserRole(userId: string, role: Role): Promise<void> {
    const supabase = getSupabaseClient();
    if (supabase) {
      await supabase.from('profiles').update({ role }).eq('id', userId);
    }

    const users: UserProfile[] = JSON.parse(localStorage.getItem(USERS_KEY) || '[]');
    const index = users.findIndex((u) => u.id === userId);
    if (index !== -1) {
      users[index].role = role;
      localStorage.setItem(USERS_KEY, JSON.stringify(users));
    }
  },

  async deleteUser(userId: string): Promise<void> {
    const supabase = getSupabaseClient();
    if (supabase) {
      try {
        await supabase.from('submissions').delete().eq('user_id', userId);
        await supabase.from('profiles').delete().eq('id', userId);
      } catch (err) {
        console.warn('Supabase delete user failed:', err);
      }
    }

    const users: UserProfile[] = JSON.parse(localStorage.getItem(USERS_KEY) || '[]');
    const targetUser = users.find((u) => u.id === userId);
    const filteredUsers = users.filter((u) => u.id !== userId);
    localStorage.setItem(USERS_KEY, JSON.stringify(filteredUsers));

    if (targetUser) {
      const passwords: Record<string, string> = JSON.parse(localStorage.getItem(PASSWORDS_KEY) || '{}');
      delete passwords[targetUser.email.toLowerCase()];
      localStorage.setItem(PASSWORDS_KEY, JSON.stringify(passwords));
    }

    // Also delete associated submissions
    const submissions: Submission[] = JSON.parse(localStorage.getItem(SUBMISSIONS_KEY) || '[]');
    const filteredSubmissions = submissions.filter((s) => s.user_id !== userId);
    localStorage.setItem(SUBMISSIONS_KEY, JSON.stringify(filteredSubmissions));
  },

  // System Settings
  async getSystemSettings(): Promise<SystemSettings> {
    const supabase = getSupabaseClient();
    if (supabase) {
      const { data, error } = await supabase.from('system_settings').select('*').eq('id', 'global').single();
      if (!error && data) {
        return {
          is_maintenance: data.is_maintenance,
          maintenance_message: data.maintenance_message,
          allow_new_submissions: data.allow_new_submissions,
          max_file_size_mb: data.max_file_size_mb,
          allowed_file_types: data.allowed_file_types,
        };
      }
    }

    const raw = localStorage.getItem(SETTINGS_KEY);
    if (raw) {
      try {
        return JSON.parse(raw);
      } catch {
        // fallback
      }
    }

    return {
      is_maintenance: false,
      maintenance_message: 'Hệ thống đang bảo trì để nâng cấp cơ sở dữ liệu và bảo mật. Vui lòng quay lại sau.',
      allow_new_submissions: true,
      max_file_size_mb: 25,
      allowed_file_types: 'pdf,docx,zip,rar,png,jpg,jpeg',
    };
  },

  async updateSystemSettings(settings: Partial<SystemSettings>): Promise<SystemSettings> {
    const current = await this.getSystemSettings();
    const updated: SystemSettings = { ...current, ...settings };

    const supabase = getSupabaseClient();
    if (supabase) {
      await supabase.from('system_settings').upsert({ id: 'global', ...updated });
    }

    localStorage.setItem(SETTINGS_KEY, JSON.stringify(updated));
    return updated;
  },

  // File Upload Helper
  async uploadFile(file: File, userId: string): Promise<SubmissionFile> {
    const supabase = getSupabaseClient();

    // If Supabase is connected and storage is configured
    if (supabase) {
      try {
        const fileExt = file.name.split('.').pop();
        const filePath = `${userId}/${Date.now()}_${Math.random().toString(36).substring(2, 7)}.${fileExt}`;

        const { data, error } = await supabase.storage.from('submissions').upload(filePath, file, {
          cacheControl: '3600',
          upsert: false,
        });

        if (!error && data) {
          // Create signed URL for private bucket (valid for 1 year)
          const { data: signedData } = await supabase.storage
            .from('submissions')
            .createSignedUrl(filePath, 60 * 60 * 24 * 365);

          return {
            name: file.name,
            size: file.size,
            type: file.type || 'application/octet-stream',
            url: signedData?.signedUrl || '',
            path: filePath,
          };
        }
      } catch (err) {
        console.warn('Supabase storage upload fallback to local Base64:', err);
      }
    }

    // Local Base64 DataURL storage
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        resolve({
          name: file.name,
          size: file.size,
          type: file.type || 'application/octet-stream',
          url: reader.result as string,
        });
      };
      reader.onerror = (error) => reject(error);
      reader.readAsDataURL(file);
    });
  },

  // Lucky Gifts Operations (Quà tặng may mắn)
  async getLuckyGifts(): Promise<LuckyGift[]> {
    const raw = localStorage.getItem(LUCKY_GIFTS_KEY);
    if (!raw) {
      localStorage.setItem(LUCKY_GIFTS_KEY, JSON.stringify(defaultLuckyGifts));
      return defaultLuckyGifts;
    }
    try {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    } catch {}
    localStorage.setItem(LUCKY_GIFTS_KEY, JSON.stringify(defaultLuckyGifts));
    return defaultLuckyGifts;
  },

  async saveLuckyGift(gift: LuckyGift): Promise<LuckyGift[]> {
    const gifts = await this.getLuckyGifts();
    const index = gifts.findIndex((g) => g.id === gift.id);
    if (index >= 0) {
      gifts[index] = gift;
    } else {
      gifts.push(gift);
    }
    localStorage.setItem(LUCKY_GIFTS_KEY, JSON.stringify(gifts));
    return gifts;
  },

  async deleteLuckyGift(id: string): Promise<LuckyGift[]> {
    const gifts = await this.getLuckyGifts();
    const updated = gifts.filter((g) => g.id !== id);
    localStorage.setItem(LUCKY_GIFTS_KEY, JSON.stringify(updated));
    return updated;
  },

  async toggleLuckyGift(id: string): Promise<LuckyGift[]> {
    const gifts = await this.getLuckyGifts();
    const target = gifts.find((g) => g.id === id);
    if (target) {
      target.is_active = !target.is_active;
      localStorage.setItem(LUCKY_GIFTS_KEY, JSON.stringify(gifts));
    }
    return gifts;
  },

  async resetLuckyGifts(): Promise<LuckyGift[]> {
    localStorage.setItem(LUCKY_GIFTS_KEY, JSON.stringify(defaultLuckyGifts));
    return defaultLuckyGifts;
  },

  // Draw gift based on active probability weights
  async rollLuckyGift(): Promise<LuckyGift | null> {
    const gifts = await this.getLuckyGifts();
    const activeGifts = gifts.filter((g) => g.is_active && g.probability > 0);

    if (activeGifts.length === 0) {
      return null;
    }

    const totalWeight = activeGifts.reduce((sum, g) => sum + Math.max(0, g.probability), 0);
    if (totalWeight <= 0) {
      return activeGifts[0];
    }

    let random = Math.random() * totalWeight;
    for (const gift of activeGifts) {
      if (random < gift.probability) {
        return gift;
      }
      random -= gift.probability;
    }
    return activeGifts[activeGifts.length - 1];
  },
};
