import React, { useState, useEffect } from 'react';
import { 
  Clock, 
  CheckCircle2, 
  XCircle, 
  AlertCircle, 
  FileText, 
  Download, 
  ExternalLink, 
  Search, 
  Filter, 
  Eye, 
  Calendar, 
  User, 
  FileDown, 
  ArrowUpRight,
  MessageSquareQuote,
  RefreshCw,
  PlusCircle
} from 'lucide-react';
import { Submission, UserProfile, SubmissionStatus } from '../types';
import { dbService } from '../services/db';

interface SubmissionListProps {
  user: UserProfile;
  onGoToSubmit: () => void;
}

export const SubmissionList: React.FC<SubmissionListProps> = ({ user, onGoToSubmit }) => {
  const [submissions, setSubmissions] = useState<Submission[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | SubmissionStatus>('all');
  const [selectedSubmission, setSelectedSubmission] = useState<Submission | null>(null);

  const fetchSubmissions = async () => {
    setLoading(true);
    try {
      const data = await dbService.getUserSubmissions(user.id);
      setSubmissions(data);
    } catch (err) {
      console.error('Error fetching user submissions:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSubmissions();
  }, [user.id]);

  const filteredList = submissions.filter((item) => {
    const matchesSearch =
      item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.content.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || item.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const getStatusBadge = (status: SubmissionStatus) => {
    switch (status) {
      case 'approved':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-100/90 text-emerald-800 border border-emerald-300">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
            Đã Duyệt
          </span>
        );
      case 'rejected':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-rose-100/90 text-rose-800 border border-rose-300">
            <XCircle className="w-3.5 h-3.5 text-rose-600" />
            Từ Chối
          </span>
        );
      case 'pending':
      default:
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-amber-100/90 text-amber-800 border border-amber-300">
            <Clock className="w-3.5 h-3.5 text-amber-600 animate-spin" />
            Chờ Phê Duyệt
          </span>
        );
    }
  };

  const formatDate = (isoString: string) => {
    try {
      const d = new Date(isoString);
      return d.toLocaleDateString('vi-VN', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      });
    } catch {
      return isoString;
    }
  };

  // Secure download helper
  const handleDownload = (sub: Submission) => {
    if (!sub.file?.url) return;
    const link = document.createElement('a');
    link.href = sub.file.url;
    link.download = sub.file.name || 'bai_nop.pdf';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="max-w-5xl mx-auto py-4 sm:py-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-800 tracking-tight">
            Lịch Sử Bài Nộp <span className="text-emerald-600">TNedu</span>
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Theo dõi tiến độ, phản hồi và kết quả đánh giá các bài tập trên hệ thống TNedu.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={fetchSubmissions}
            title="Làm mới danh sách"
            className="p-2.5 bg-white border border-slate-200 text-slate-600 hover:text-emerald-600 hover:border-emerald-300 rounded-xl transition-all shadow-xs cursor-pointer"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>

          <button
            onClick={onGoToSubmit}
            className="flex items-center gap-2 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-sm font-semibold shadow-sm shadow-emerald-600/30 transition-all cursor-pointer"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Nộp bài mới</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-2xl shadow-xs border border-emerald-100 flex flex-col md:flex-row gap-3 items-center justify-between">
        {/* Search Input */}
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Tìm theo tiêu đề hoặc nội dung..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/30 focus:border-emerald-500 text-slate-800"
          />
        </div>

        {/* Status Filter Buttons */}
        <div className="flex items-center gap-1.5 w-full md:w-auto overflow-x-auto pb-1 md:pb-0">
          <button
            onClick={() => setStatusFilter('all')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
              statusFilter === 'all'
                ? 'bg-slate-800 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            Tất cả ({submissions.length})
          </button>
          <button
            onClick={() => setStatusFilter('pending')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
              statusFilter === 'pending'
                ? 'bg-amber-500 text-white shadow-xs'
                : 'bg-amber-50 text-amber-700 hover:bg-amber-100 border border-amber-200'
            }`}
          >
            Chờ duyệt ({submissions.filter((s) => s.status === 'pending').length})
          </button>
          <button
            onClick={() => setStatusFilter('approved')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
              statusFilter === 'approved'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border border-emerald-200'
            }`}
          >
            Đã duyệt ({submissions.filter((s) => s.status === 'approved').length})
          </button>
          <button
            onClick={() => setStatusFilter('rejected')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
              statusFilter === 'rejected'
                ? 'bg-rose-600 text-white shadow-xs'
                : 'bg-rose-50 text-rose-700 hover:bg-rose-100 border border-rose-200'
            }`}
          >
            Từ chối ({submissions.filter((s) => s.status === 'rejected').length})
          </button>
        </div>
      </div>

      {/* Submissions List */}
      {loading ? (
        <div className="py-16 text-center bg-white rounded-3xl border border-slate-200">
          <RefreshCw className="w-8 h-8 text-emerald-600 animate-spin mx-auto mb-3" />
          <p className="text-sm font-semibold text-slate-600">Đang tải lịch sử bài nộp...</p>
        </div>
      ) : filteredList.length === 0 ? (
        <div className="py-16 text-center bg-white rounded-3xl border border-slate-200/80 p-8 shadow-xs">
          <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
            <FileText className="w-8 h-8" />
          </div>
          <h3 className="text-lg font-bold text-slate-800">Không tìm thấy bài nộp nào</h3>
          <p className="text-sm text-slate-500 max-w-md mx-auto mt-1 mb-6">
            {searchQuery || statusFilter !== 'all'
              ? 'Thử thay đổi từ khóa tìm kiếm hoặc bộ lọc trạng thái.'
              : 'Bạn chưa nộp bài tập nào vào hệ thống. Hãy bắt đầu nộp bài đầu tiên ngay bây giờ!'}
          </p>
          <button
            onClick={onGoToSubmit}
            className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-xl text-sm transition-all cursor-pointer inline-flex items-center gap-2"
          >
            <PlusCircle className="w-4 h-4" />
            Nộp bài tập mới
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredList.map((item) => (
            <div
              key={item.id}
              className="bg-white rounded-2xl border border-emerald-100 hover:border-emerald-300 p-5 sm:p-6 shadow-xs hover:shadow-md transition-all space-y-4 group"
            >
              <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3">
                <div className="space-y-1">
                  <div className="flex items-center gap-2.5 flex-wrap">
                    {getStatusBadge(item.status)}
                    <span className="text-xs text-slate-400 flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5" />
                      {formatDate(item.created_at)}
                    </span>
                  </div>
                  <h3 className="text-lg font-bold text-slate-800 group-hover:text-emerald-700 transition-colors pt-1">
                    {item.title}
                  </h3>
                </div>

                <button
                  onClick={() => setSelectedSubmission(item)}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 rounded-lg transition-colors cursor-pointer self-start sm:self-auto"
                >
                  <Eye className="w-3.5 h-3.5" />
                  Xem chi tiết
                </button>
              </div>

              {/* Snippet Content */}
              <p className="text-sm text-slate-600 line-clamp-2 leading-relaxed">
                {item.content}
              </p>

              {/* Attachments pills */}
              <div className="flex items-center gap-3 pt-2 border-t border-slate-100 flex-wrap text-xs">
                {item.link_url && (
                  <a
                    href={item.link_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 text-emerald-600 hover:text-emerald-800 hover:underline font-medium"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    <span>Mở link bài nộp</span>
                  </a>
                )}

                {item.file && (
                  <button
                    onClick={() => handleDownload(item)}
                    className="inline-flex items-center gap-1.5 text-slate-700 hover:text-emerald-700 font-medium bg-slate-100 hover:bg-emerald-50 px-2.5 py-1 rounded-md transition-colors cursor-pointer"
                  >
                    <FileDown className="w-3.5 h-3.5 text-emerald-600" />
                    <span className="truncate max-w-[200px]">{item.file.name}</span>
                  </button>
                )}
              </div>

              {/* If Rejected: Prominently show Rejection Reason! */}
              {item.status === 'rejected' && item.admin_feedback && (
                <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-900 flex items-start gap-2.5">
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-rose-800">Lý do từ chối từ Giảng viên/Admin: </span>
                    <span className="font-medium">{item.admin_feedback}</span>
                  </div>
                </div>
              )}

              {/* If Approved: show note */}
              {item.status === 'approved' && item.admin_feedback && (
                <div className="p-3 bg-emerald-50/80 border border-emerald-200 rounded-xl text-xs text-emerald-900 flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-emerald-800">Nhận xét của Giảng viên: </span>
                    <span>{item.admin_feedback}</span>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Details Modal */}
      {selectedSubmission && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto"
          onClick={() => setSelectedSubmission(null)}
        >
          <div 
            className="w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-emerald-100 overflow-hidden my-8"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="p-6 bg-slate-50 border-b border-slate-200 flex items-start justify-between gap-4">
              <div>
                <div className="flex items-center gap-2 mb-1.5">
                  {getStatusBadge(selectedSubmission.status)}
                  <span className="text-xs text-slate-500">Mã bài: {selectedSubmission.id}</span>
                </div>
                <h3 className="text-xl font-bold text-slate-800">
                  {selectedSubmission.title}
                </h3>
              </div>
              <button
                onClick={() => setSelectedSubmission(null)}
                className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-200 rounded-full transition-colors"
              >
                ✕
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-6 space-y-6 max-h-[70vh] overflow-y-auto">
              {/* Submission metadata */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs bg-slate-50 p-4 rounded-xl border border-slate-200">
                <div>
                  <span className="text-slate-400 block">Thời gian nộp:</span>
                  <span className="font-semibold text-slate-700">{formatDate(selectedSubmission.created_at)}</span>
                </div>
                <div>
                  <span className="text-slate-400 block">Người nộp:</span>
                  <span className="font-semibold text-slate-700">{selectedSubmission.user_name}</span>
                </div>
                <div>
                  <span className="text-slate-400 block">Email:</span>
                  <span className="font-semibold text-slate-700">{selectedSubmission.user_email}</span>
                </div>
              </div>

              {/* Full Content */}
              <div>
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
                  Nội dung & Thuyết minh bài nộp
                </h4>
                <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 text-sm text-slate-800 leading-relaxed whitespace-pre-wrap">
                  {selectedSubmission.content}
                </div>
              </div>

              {/* Link */}
              {selectedSubmission.link_url && (
                <div>
                  <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
                    Liên kết dự án
                  </h4>
                  <a
                    href={selectedSubmission.link_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-between p-3.5 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 hover:bg-emerald-100 transition-colors text-sm font-medium"
                  >
                    <span className="truncate">{selectedSubmission.link_url}</span>
                    <ArrowUpRight className="w-4 h-4 shrink-0 text-emerald-600" />
                  </a>
                </div>
              )}

              {/* Attached file */}
              {selectedSubmission.file && (
                <div>
                  <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
                    Tệp đính kèm (Bảo mật cho riêng bạn)
                  </h4>
                  <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl flex items-center justify-between gap-4">
                    <div className="flex items-center gap-3 overflow-hidden">
                      <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
                        <FileText className="w-5 h-5" />
                      </div>
                      <div className="overflow-hidden">
                        <p className="text-sm font-semibold text-slate-800 truncate">
                          {selectedSubmission.file.name}
                        </p>
                        <p className="text-xs text-slate-500">
                          {(selectedSubmission.file.size / (1024 * 1024)).toFixed(2)} MB • {selectedSubmission.file.type}
                        </p>
                      </div>
                    </div>

                    <button
                      onClick={() => handleDownload(selectedSubmission)}
                      className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer shrink-0"
                    >
                      <Download className="w-3.5 h-3.5" />
                      Tải về máy
                    </button>
                  </div>
                </div>
              )}

              {/* Reviewer Feedback Section */}
              {selectedSubmission.status === 'rejected' && (
                <div className="p-4 bg-rose-50 border border-rose-200 rounded-2xl space-y-1.5">
                  <div className="flex items-center gap-2 text-rose-800 font-bold text-sm">
                    <XCircle className="w-4 h-4 text-rose-600" />
                    Lý do từ chối bài nộp:
                  </div>
                  <p className="text-sm text-rose-900 leading-relaxed font-medium">
                    {selectedSubmission.admin_feedback || 'Chưa có ghi chú chi tiết.'}
                  </p>
                  <p className="text-xs text-rose-600 pt-1">
                    Người duyệt: {selectedSubmission.reviewed_by || 'Ban Quản Trị'} • Thời gian: {selectedSubmission.reviewed_at ? formatDate(selectedSubmission.reviewed_at) : 'N/A'}
                  </p>
                </div>
              )}

              {selectedSubmission.status === 'approved' && selectedSubmission.admin_feedback && (
                <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl space-y-1.5">
                  <div className="flex items-center gap-2 text-emerald-800 font-bold text-sm">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    Đánh giá & Nhận xét của Giảng viên:
                  </div>
                  <p className="text-sm text-emerald-900 leading-relaxed">
                    {selectedSubmission.admin_feedback}
                  </p>
                  <p className="text-xs text-emerald-600 pt-1">
                    Người chấm: {selectedSubmission.reviewed_by || 'Ban Quản Trị'}
                  </p>
                </div>
              )}
            </div>

            {/* Modal Footer */}
            <div className="p-4 bg-slate-50 border-t border-slate-200 flex justify-end">
              <button
                onClick={() => setSelectedSubmission(null)}
                className="px-5 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 font-semibold text-xs rounded-xl transition-colors cursor-pointer"
              >
                Đóng
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
