import React, { useState } from 'react';
import { 
  GraduationCap, 
  Send, 
  Clock, 
  LogOut, 
  User as UserIcon, 
  ShieldCheck, 
  Menu,
  X
} from 'lucide-react';
import { UserProfile } from '../types';

interface NavbarProps {
  user: UserProfile | null;
  activeTab: 'submit' | 'history';
  onSelectTab: (tab: 'submit' | 'history') => void;
  onLogout: () => void;
  onOpenAuth: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  user,
  activeTab,
  onSelectTab,
  onLogout,
  onOpenAuth,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-emerald-100 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          
          {/* Logo & Brand */}
          <div className="flex items-center gap-3">
            <a 
              href="#"
              onClick={(e) => {
                e.preventDefault();
                window.location.hash = '';
                onSelectTab('submit');
              }}
              className="flex items-center gap-2.5 group focus:outline-none"
            >
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center text-white shadow-md shadow-emerald-600/20 group-hover:scale-105 transition-transform">
                <GraduationCap className="w-5 h-5" />
              </div>
              <div className="flex flex-col">
                <span className="text-xl font-extrabold tracking-tight text-slate-900 leading-none">
                  TN<span className="text-emerald-600">edu</span>
                </span>
                <span className="text-[11px] font-semibold text-emerald-700 mt-0.5 tracking-wide">
                  Nộp Bài Online
                </span>
              </div>
            </a>
          </div>

          {/* Desktop Navigation */}
          {user ? (
            <div className="hidden md:flex items-center gap-2">
              <nav className="flex items-center p-1 bg-slate-100/80 rounded-xl border border-slate-200/80">
                <button
                  onClick={() => onSelectTab('submit')}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold transition-all cursor-pointer ${
                    activeTab === 'submit'
                      ? 'bg-white text-emerald-700 shadow-sm'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Send className="w-4 h-4" />
                  <span>Nộp bài mới</span>
                </button>
                <button
                  onClick={() => onSelectTab('history')}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold transition-all cursor-pointer ${
                    activeTab === 'history'
                      ? 'bg-white text-emerald-700 shadow-sm'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Clock className="w-4 h-4" />
                  <span>Lịch sử bài nộp</span>
                </button>
              </nav>

              {/* Profile & Controls */}
              <div className="flex items-center gap-3 pl-4 border-l border-slate-200 ml-2">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-full bg-emerald-100 text-emerald-800 font-bold flex items-center justify-center text-sm border border-emerald-200">
                    {user.full_name ? user.full_name.charAt(0).toUpperCase() : 'U'}
                  </div>
                  <div className="hidden lg:flex flex-col text-left">
                    <span className="text-sm font-semibold text-slate-800 leading-tight">
                      {user.full_name || user.email}
                    </span>
                    <span className="text-[11px] text-slate-500 flex items-center gap-1">
                      {user.role === 'admin' ? (
                        <span className="text-emerald-700 font-medium flex items-center gap-0.5">
                          <ShieldCheck className="w-3 h-3 inline" /> Ban Quản Trị
                        </span>
                      ) : (
                        'Học viên'
                      )}
                    </span>
                  </div>
                </div>

                {user.role === 'admin' && (
                  <a
                    href="#adminbas"
                    className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-xl bg-slate-900 text-white hover:bg-slate-800 shadow-sm transition-all"
                    title="Mở cổng quản trị (#adminbas)"
                  >
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Vào #adminbas</span>
                  </a>
                )}

                <button
                  onClick={onLogout}
                  title="Đăng xuất"
                  className="p-2 text-slate-500 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            </div>
          ) : (
            <div className="hidden md:flex items-center gap-3">
              <button
                onClick={onOpenAuth}
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-sm shadow-sm shadow-emerald-600/30 transition-all cursor-pointer"
              >
                <UserIcon className="w-4 h-4" />
                <span>Đăng nhập / Đăng ký</span>
              </button>
            </div>
          )}

          {/* Mobile menu trigger */}
          <div className="flex md:hidden items-center gap-2">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg text-slate-600 hover:bg-slate-100"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white border-b border-emerald-100 px-4 pt-3 pb-5 space-y-3 shadow-lg">
          {user ? (
            <>
              <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl border border-slate-200">
                <div className="w-10 h-10 rounded-full bg-emerald-100 text-emerald-800 font-bold flex items-center justify-center">
                  {user.full_name ? user.full_name.charAt(0).toUpperCase() : 'U'}
                </div>
                <div>
                  <p className="font-semibold text-slate-800 text-sm">{user.full_name}</p>
                  <p className="text-xs text-slate-500">{user.email}</p>
                  <span className="inline-block mt-0.5 text-[10px] font-semibold uppercase tracking-wider text-emerald-700 bg-emerald-100/60 px-1.5 py-0.5 rounded">
                    {user.role === 'admin' ? 'Quản trị viên' : 'Học viên'}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => {
                    onSelectTab('submit');
                    setMobileMenuOpen(false);
                  }}
                  className={`flex items-center justify-center gap-2 p-2.5 rounded-xl text-sm font-semibold ${
                    activeTab === 'submit' ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-700'
                  }`}
                >
                  <Send className="w-4 h-4" />
                  Nộp bài mới
                </button>
                <button
                  onClick={() => {
                    onSelectTab('history');
                    setMobileMenuOpen(false);
                  }}
                  className={`flex items-center justify-center gap-2 p-2.5 rounded-xl text-sm font-semibold ${
                    activeTab === 'history' ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-700'
                  }`}
                >
                  <Clock className="w-4 h-4" />
                  Lịch sử bài
                </button>
              </div>

              <button
                onClick={() => {
                  onLogout();
                  setMobileMenuOpen(false);
                }}
                className="w-full flex items-center justify-center gap-2 p-2.5 text-sm font-medium text-rose-600 bg-rose-50 rounded-xl"
              >
                <LogOut className="w-4 h-4" />
                Đăng xuất
              </button>
            </>
          ) : (
            <button
              onClick={() => {
                onOpenAuth();
                setMobileMenuOpen(false);
              }}
              className="w-full py-3 bg-emerald-600 text-white font-semibold rounded-xl text-sm shadow-md"
            >
              Đăng nhập / Đăng ký
            </button>
          )}
        </div>
      )}
    </header>
  );
};
