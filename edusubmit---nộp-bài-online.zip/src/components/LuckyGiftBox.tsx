import React, { useState, useEffect, useRef } from 'react';
import { Gift, Sparkles, PartyPopper, Coins, RotateCcw, X, Volume2, VolumeX, CheckCircle2 } from 'lucide-react';
import { LuckyGift } from '../types';
import { dbService } from '../services/db';

export const LuckyGiftBox: React.FC = () => {
  const [isOpenModal, setIsOpenModal] = useState(false);
  const [status, setStatus] = useState<'idle' | 'shaking' | 'revealed'>('idle');
  const [countdown, setCountdown] = useState(5);
  const [wonGift, setWonGift] = useState<LuckyGift | null>(null);
  const [soundEnabled, setSoundEnabled] = useState(true);

  // Audio effect generator using Web Audio API
  const playSound = (type: 'tick' | 'win') => {
    if (!soundEnabled) return;
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();

      if (type === 'tick') {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(440 + (5 - countdown) * 80, ctx.currentTime);
        gain.gain.setValueAtTime(0.15, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.1);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 0.1);
      } else if (type === 'win') {
        const notes = [523.25, 659.25, 783.99, 1046.50]; // C5, E5, G5, C6 arpeggio
        notes.forEach((freq, idx) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = 'sine';
          osc.frequency.setValueAtTime(freq, ctx.currentTime + idx * 0.12);
          gain.gain.setValueAtTime(0.25, ctx.currentTime + idx * 0.12);
          gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + idx * 0.12 + 0.4);
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start(ctx.currentTime + idx * 0.12);
          osc.stop(ctx.currentTime + idx * 0.12 + 0.45);
        });
      }
    } catch {}
  };

  const handleStartOpen = async () => {
    if (status === 'shaking') return;
    setStatus('shaking');
    setCountdown(5);

    // Roll result from db
    const rolled = await dbService.rollLuckyGift();
    setWonGift(rolled);

    let timeLeft = 5;
    playSound('tick');

    const interval = setInterval(() => {
      timeLeft -= 1;
      setCountdown(timeLeft);
      playSound('tick');

      if (timeLeft <= 0) {
        clearInterval(interval);
        setStatus('revealed');
        playSound('win');
      }
    }, 1000);
  };

  const handleReset = () => {
    setStatus('idle');
    setCountdown(5);
    setWonGift(null);
  };

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(val);
  };

  return (
    <>
      {/* LUCKY BOX BOTTOM BANNER IN MEMBER PAGE */}
      <section className="my-8 max-w-4xl mx-auto px-4">
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-amber-500 via-emerald-600 to-teal-700 p-1 shadow-xl group">
          <div className="bg-slate-900/90 backdrop-blur-md rounded-[22px] p-6 sm:p-8 flex flex-col sm:flex-row items-center justify-between gap-6 text-white relative">
            {/* Sparkle decorative dots */}
            <div className="absolute top-2 right-4 text-amber-300 animate-pulse">
              <Sparkles className="w-5 h-5" />
            </div>

            <div className="flex items-center gap-4 text-center sm:text-left flex-col sm:flex-row">
              <div 
                onClick={() => {
                  setIsOpenModal(true);
                  handleReset();
                }}
                className="w-20 h-20 rounded-2xl bg-gradient-to-tr from-amber-400 to-yellow-300 text-slate-950 flex items-center justify-center shadow-lg shadow-amber-400/40 cursor-pointer hover:scale-110 active:scale-95 transition-all animate-bounce"
                title="Bấm để mở hộp quà may mắn!"
              >
                <Gift className="w-10 h-10" />
              </div>

              <div>
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-400/20 text-amber-300 text-xs font-bold border border-amber-400/30 mb-2">
                  <Coins className="w-3.5 h-3.5" />
                  <span>Hộp Quà May Mắn TNedu</span>
                </div>
                <h3 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight">
                  Mở Hộp Quà Tặng Tiền May Mắn 🎉
                </h3>
                <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-md">
                  Nhận ngay tiền lì xì may mắn ngẫu nhiên từ hệ thống TNedu. Bấm vào hộp quà để bắt đầu quay thưởng!
                </p>
              </div>
            </div>

            <button
              onClick={() => {
                setIsOpenModal(true);
                handleReset();
              }}
              className="w-full sm:w-auto px-6 py-3.5 bg-gradient-to-r from-amber-400 to-yellow-400 hover:from-amber-300 hover:to-yellow-300 text-slate-950 font-bold rounded-2xl shadow-lg shadow-amber-400/30 transition-all flex items-center justify-center gap-2 cursor-pointer text-sm shrink-0 hover:scale-105 active:scale-95"
            >
              <Gift className="w-5 h-5" />
              <span>Mở Hộp Quà Ngay</span>
            </button>
          </div>
        </div>
      </section>

      {/* MODAL OPENING ANIMATION */}
      {isOpenModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-fade-in">
          <div 
            className="w-full max-w-md bg-slate-900 border border-amber-500/40 rounded-3xl p-6 sm:p-8 shadow-2xl relative text-white overflow-hidden text-center"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Top controls */}
            <div className="flex items-center justify-between mb-4">
              <button
                onClick={() => setSoundEnabled(!soundEnabled)}
                className="p-2 text-slate-400 hover:text-white rounded-xl bg-slate-800"
                title={soundEnabled ? 'Tắt âm thanh' : 'Bật âm thanh'}
              >
                {soundEnabled ? <Volume2 className="w-4 h-4 text-emerald-400" /> : <VolumeX className="w-4 h-4" />}
              </button>

              <span className="text-xs font-bold text-amber-400 flex items-center gap-1">
                <Coins className="w-3.5 h-3.5" />
                Lì Xì May Mắn TNedu
              </span>

              <button
                onClick={() => setIsOpenModal(false)}
                className="p-2 text-slate-400 hover:text-white rounded-xl bg-slate-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* STAGE 1: IDLE */}
            {status === 'idle' && (
              <div className="space-y-6 py-4">
                <div 
                  onClick={handleStartOpen}
                  className="w-32 h-32 mx-auto rounded-3xl bg-gradient-to-tr from-amber-500 via-amber-400 to-yellow-300 text-slate-950 flex items-center justify-center shadow-2xl shadow-amber-500/50 cursor-pointer hover:scale-105 active:scale-95 transition-all group"
                >
                  <Gift className="w-16 h-16 group-hover:rotate-12 transition-transform duration-300" />
                </div>

                <div>
                  <h4 className="text-xl font-extrabold text-white">Bấm vào hộp quà để mở</h4>
                  <p className="text-xs text-slate-400 mt-1.5 max-w-xs mx-auto">
                    Hộp quà sẽ rung lắc trong vòng 5 giây để kích hoạt vận may và mở ra số tiền thưởng bất ngờ!
                  </p>
                </div>

                <button
                  onClick={handleStartOpen}
                  className="w-full py-3.5 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-white font-bold rounded-2xl shadow-lg shadow-emerald-900/50 text-sm transition-all cursor-pointer flex items-center justify-center gap-2"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>Kích hoạt Rung & Mở Quà</span>
                </button>
              </div>
            )}

            {/* STAGE 2: SHAKING (5 SECONDS EXACTLY) */}
            {status === 'shaking' && (
              <div className="space-y-6 py-4">
                {/* Custom CSS Inline Keyframes for intense 5s shaking */}
                <style>{`
                  @keyframes giftShake {
                    0% { transform: translate(0, 0) rotate(0deg) scale(1); }
                    10% { transform: translate(-6px, -4px) rotate(-8deg) scale(1.03); }
                    20% { transform: translate(6px, 4px) rotate(8deg) scale(1.05); }
                    30% { transform: translate(-8px, 2px) rotate(-10deg) scale(1.08); }
                    40% { transform: translate(8px, -2px) rotate(10deg) scale(1.06); }
                    50% { transform: translate(-6px, -6px) rotate(-12deg) scale(1.1); }
                    60% { transform: translate(6px, 6px) rotate(12deg) scale(1.08); }
                    70% { transform: translate(-8px, 4px) rotate(-10deg) scale(1.12); }
                    80% { transform: translate(8px, -4px) rotate(10deg) scale(1.1); }
                    90% { transform: translate(-4px, 2px) rotate(-6deg) scale(1.08); }
                    100% { transform: translate(0, 0) rotate(0deg) scale(1.05); }
                  }
                  .animate-gift-shake {
                    animation: giftShake 0.22s infinite ease-in-out;
                  }
                `}</style>

                <div className="relative">
                  <div className="w-32 h-32 mx-auto rounded-3xl bg-gradient-to-tr from-amber-500 via-amber-400 to-yellow-300 text-slate-950 flex items-center justify-center shadow-2xl shadow-amber-400/60 animate-gift-shake">
                    <Gift className="w-16 h-16" />
                  </div>

                  {/* Pulsing countdown circle */}
                  <div className="absolute -top-3 -right-3 w-12 h-12 rounded-full bg-rose-500 text-white font-extrabold flex items-center justify-center text-lg border-2 border-white shadow-xl animate-ping" />
                  <div className="absolute -top-3 -right-3 w-12 h-12 rounded-full bg-rose-600 text-white font-extrabold flex items-center justify-center text-lg border-2 border-white shadow-xl">
                    {countdown}s
                  </div>
                </div>

                <div>
                  <h4 className="text-xl font-extrabold text-amber-300 animate-pulse">
                    Đang rung lắc tìm may mắn... ({countdown}s)
                  </h4>
                  <p className="text-xs text-slate-400 mt-1">
                    Chuẩn bị tinh thần đón nhận phần quà may mắn bất ngờ!
                  </p>
                </div>

                <div className="w-full bg-slate-800 rounded-full h-2.5 overflow-hidden border border-slate-700">
                  <div 
                    className="bg-gradient-to-r from-amber-400 to-emerald-400 h-2.5 transition-all duration-1000 ease-linear rounded-full"
                    style={{ width: `${((5 - countdown) / 5) * 100}%` }}
                  />
                </div>
              </div>
            )}

            {/* STAGE 3: REVEALED */}
            {status === 'revealed' && (
              <div className="space-y-6 py-4 animate-scale-up">
                <div className="w-24 h-24 mx-auto rounded-3xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/40 shadow-xl shadow-emerald-500/20">
                  <PartyPopper className="w-12 h-12 animate-bounce" />
                </div>

                {wonGift ? (
                  <div className="space-y-2">
                    <span className="text-xs font-bold text-amber-400 uppercase tracking-widest">
                      CHÚC MỪNG BẠN NHẬN ĐƯỢC!
                    </span>
                    <h4 className="text-2xl font-extrabold text-white tracking-tight">
                      {wonGift.name}
                    </h4>
                    {wonGift.amount > 0 && (
                      <div className="inline-block px-5 py-2 rounded-2xl bg-gradient-to-r from-amber-500/20 to-yellow-500/20 border border-amber-400/40 text-amber-300 font-extrabold text-xl font-mono">
                        +{formatCurrency(wonGift.amount)}
                      </div>
                    )}
                    <p className="text-xs text-slate-300 mt-2 max-w-xs mx-auto leading-relaxed">
                      {wonGift.description || 'TNedu chúc bạn một ngày học tập thật nhiều năng lượng và may mắn!'}
                    </p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    <h4 className="text-xl font-bold text-slate-300">
                      Hiện tại các phần quà đang được cập nhật
                    </h4>
                    <p className="text-xs text-slate-400">
                      Quản trị viên đang cấu hình thêm các phần quà mới trong cổng quản trị.
                    </p>
                  </div>
                )}

                <div className="flex items-center gap-3 pt-2">
                  <button
                    onClick={handleReset}
                    className="flex-1 py-3 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold rounded-2xl text-xs transition-colors flex items-center justify-center gap-2 cursor-pointer border border-slate-700"
                  >
                    <RotateCcw className="w-4 h-4" />
                    <span>Mở Lượt Khác</span>
                  </button>

                  <button
                    onClick={() => setIsOpenModal(false)}
                    className="flex-1 py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-2xl text-xs transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-emerald-950"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Nhận Thưởng</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </>
  );
};
