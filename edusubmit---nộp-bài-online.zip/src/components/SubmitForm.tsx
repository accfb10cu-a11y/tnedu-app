import React, { useState, useRef } from 'react';
import { 
  Send, 
  UploadCloud, 
  File, 
  Image as ImageIcon, 
  Link as LinkIcon, 
  FileText, 
  X, 
  CheckCircle2, 
  AlertCircle,
  HelpCircle,
  ExternalLink,
  Sparkles
} from 'lucide-react';
import { UserProfile, SubmissionFile } from '../types';
import { dbService } from '../services/db';

interface SubmitFormProps {
  user: UserProfile;
  onSubmittedSuccess: () => void;
}

export const SubmitForm: React.FC<SubmitFormProps> = ({ user, onSubmittedSuccess }) => {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [linkUrl, setLinkUrl] = useState('');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [filePreview, setFilePreview] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const handleFileChange = (file: File) => {
    // Validate size (max 25MB)
    if (file.size > 25 * 1024 * 1024) {
      setError('Kích thước tệp vượt quá giới hạn 25MB.');
      return;
    }
    setError(null);
    setSelectedFile(file);

    // If image, create thumbnail preview
    if (file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setFilePreview(e.target?.result as string);
      };
      reader.readAsDataURL(file);
    } else {
      setFilePreview(null);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFileChange(e.dataTransfer.files[0]);
    }
  };

  const removeFile = () => {
    setSelectedFile(null);
    setFilePreview(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMsg(null);

    if (!title.trim()) {
      setError('Vui lòng nhập tiêu đề bài nộp.');
      return;
    }
    if (!content.trim()) {
      setError('Vui lòng nhập nội dung mô tả bài nộp.');
      return;
    }

    setSubmitting(true);
    try {
      let uploadedFileInfo: SubmissionFile | undefined = undefined;

      if (selectedFile) {
        uploadedFileInfo = await dbService.uploadFile(selectedFile, user.id);
      }

      await dbService.createSubmission({
        user_id: user.id,
        user_name: user.full_name || user.email,
        user_email: user.email,
        title: title.trim(),
        content: content.trim(),
        link_url: linkUrl.trim() || undefined,
        file: uploadedFileInfo,
      });

      setSuccessMsg('Nộp bài thành công! Hệ thống đang chuyển đến danh sách theo dõi...');
      
      // Reset form
      setTitle('');
      setContent('');
      setLinkUrl('');
      removeFile();

      setTimeout(() => {
        onSubmittedSuccess();
      }, 1200);
    } catch (err: any) {
      setError(err?.message || 'Có lỗi xảy ra khi nộp bài. Vui lòng thử lại.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto py-4 sm:py-8">
      {/* Intro Header */}
      <div className="mb-6 text-center sm:text-left flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 text-emerald-800 text-xs font-bold border border-emerald-200/80 mb-2">
            <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
            TNedu • Không gian học tập & Nộp bài
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Nộp Bài Trực Tuyến <span className="text-emerald-600">TNedu</span>
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Gửi bài tập, liên kết dự án hoặc đính kèm tệp tin đến hệ thống đào tạo TNedu.
          </p>
        </div>
        <div className="hidden sm:block text-right">
          <span className="text-xs text-slate-400 block">Thành viên:</span>
          <span className="text-sm font-bold text-slate-700">{user.full_name || user.email}</span>
        </div>
      </div>

      {/* Main Card */}
      <div className="bg-white rounded-3xl shadow-sm border border-emerald-100/80 overflow-hidden">
        {/* Banner strip */}
        <div className="h-1.5 bg-gradient-to-r from-emerald-500 via-teal-400 to-emerald-600" />

        <form onSubmit={handleSubmit} className="p-6 sm:p-8 space-y-6">
          {error && (
            <div className="p-4 bg-rose-50 border border-rose-200 rounded-2xl flex items-start gap-3 text-rose-800 text-sm">
              <AlertCircle className="w-5 h-5 shrink-0 text-rose-600 mt-0.5" />
              <div>
                <p className="font-semibold">Không thể gửi bài</p>
                <p className="text-xs text-rose-700 mt-0.5">{error}</p>
              </div>
            </div>
          )}

          {successMsg && (
            <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl flex items-start gap-3 text-emerald-800 text-sm animate-fade-in">
              <CheckCircle2 className="w-5 h-5 shrink-0 text-emerald-600 mt-0.5" />
              <div>
                <p className="font-semibold">Thành công!</p>
                <p className="text-xs text-emerald-700 mt-0.5">{successMsg}</p>
              </div>
            </div>
          )}

          {/* 1. Submission Title */}
          <div>
            <label className="block text-sm font-semibold text-slate-800 mb-2">
              Tiêu đề bài nộp <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              required
              placeholder="Ví dụ: Báo cáo Đồ án Cuối kỳ - Nhóm 04"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/30 focus:border-emerald-500 transition-all text-slate-900 placeholder-slate-400 font-medium"
            />
          </div>

          {/* 2. Submission Description / Content */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-sm font-semibold text-slate-800">
                Nội dung / Mô tả giải pháp <span className="text-rose-500">*</span>
              </label>
              <span className="text-xs text-slate-400">{content.length} ký tự</span>
            </div>
            <textarea
              required
              rows={4}
              placeholder="Mô tả tóm tắt quá trình thực hiện bài tập, cấu trúc mã nguồn, các chức năng đã hoàn thành hoặc lưu ý đối với người chấm..."
              value={content}
              onChange={(e) => setContent(e.target.value)}
              className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/30 focus:border-emerald-500 transition-all text-slate-900 placeholder-slate-400 leading-relaxed"
            />
          </div>

          {/* 3. Link URL */}
          <div>
            <label className="block text-sm font-semibold text-slate-800 mb-2">
              Gửi đường link đính kèm <span className="text-xs font-normal text-slate-500">(Tùy chọn)</span>
            </label>
            <div className="relative">
              <LinkIcon className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="url"
                placeholder="Dán đường link bài nộp tại đây (https://...)"
                value={linkUrl}
                onChange={(e) => setLinkUrl(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/30 focus:border-emerald-500 transition-all text-slate-900 placeholder-slate-400"
              />
            </div>
            <p className="text-[11px] text-slate-600 mt-1 flex items-center gap-1">
              <HelpCircle className="w-3 h-3 text-slate-600" />
              Bạn có thể dán đường link tài liệu, video bài tập, slide thuyết trình hoặc website.
            </p>
          </div>

          {/* 4. File / Image Upload */}
          <div>
            <label className="block text-sm font-semibold text-slate-800 mb-2">
              Tải tệp tin / Hình ảnh <span className="text-xs font-normal text-slate-500">(Tùy chọn, tối đa 25MB)</span>
            </label>

            {!selectedFile ? (
              <div
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
                onClick={() => fileInputRef.current?.click()}
                className={`border-2 border-dashed rounded-2xl p-6 sm:p-8 text-center cursor-pointer transition-all ${
                  isDragging
                    ? 'border-emerald-500 bg-emerald-50/60 scale-[1.01]'
                    : 'border-slate-200 hover:border-emerald-400 hover:bg-emerald-50/20 bg-slate-50/50'
                }`}
              >
                <input
                  type="file"
                  ref={fileInputRef}
                  className="hidden"
                  onChange={(e) => {
                    if (e.target.files && e.target.files[0]) {
                      handleFileChange(e.target.files[0]);
                    }
                  }}
                  accept=".pdf,.docx,.doc,.zip,.rar,.png,.jpg,.jpeg,.xlsx,.pptx"
                />
                <div className="w-14 h-14 mx-auto mb-3 rounded-2xl bg-emerald-100/80 text-emerald-700 flex items-center justify-center">
                  <UploadCloud className="w-7 h-7" />
                </div>
                <p className="text-sm font-semibold text-slate-800">
                  Kéo thả tệp tin hoặc <span className="text-emerald-600 underline">chọn từ thiết bị</span>
                </p>
                <p className="text-xs text-slate-400 mt-1">
                  Hỗ trợ PDF, Word, ZIP, RAR hoặc ảnh PNG, JPG (Tối đa 25MB)
                </p>
              </div>
            ) : (
              <div className="p-4 bg-slate-50 border border-emerald-200 rounded-2xl flex items-center justify-between gap-4">
                <div className="flex items-center gap-3 overflow-hidden">
                  {filePreview ? (
                    <img
                      src={filePreview}
                      alt="Xem trước"
                      className="w-14 h-14 rounded-xl object-cover border border-slate-200 shrink-0"
                    />
                  ) : (
                    <div className="w-12 h-12 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
                      <FileText className="w-6 h-6" />
                    </div>
                  )}

                  <div className="overflow-hidden">
                    <p className="text-sm font-semibold text-slate-800 truncate" title={selectedFile.name}>
                      {selectedFile.name}
                    </p>
                    <p className="text-xs text-slate-500 mt-0.5 flex items-center gap-2">
                      <span>{formatFileSize(selectedFile.size)}</span>
                      <span>•</span>
                      <span className="uppercase text-[10px] bg-slate-200 px-1.5 py-0.5 rounded font-mono">
                        {selectedFile.name.split('.').pop()}
                      </span>
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={removeFile}
                  className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-colors cursor-pointer shrink-0"
                  title="Xóa tệp này"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            )}
          </div>

          {/* Submit Action */}
          <div className="pt-4 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="text-xs text-slate-600 text-center sm:text-left">
              🔒 Bài nộp được lưu trữ an toàn với cơ chế bảo mật Private Storage và RLS.
            </div>

            <button
              type="submit"
              disabled={submitting}
              className="w-full sm:w-auto px-8 py-3.5 bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 disabled:opacity-50 text-white font-bold text-sm rounded-xl shadow-lg shadow-emerald-600/30 transition-all flex items-center justify-center gap-2.5 cursor-pointer"
            >
              {submitting ? (
                <>
                  <span className="inline-block w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  <span>Đang tải lên & nộp bài...</span>
                </>
              ) : (
                <>
                  <Send className="w-4 h-4" />
                  <span>Xác nhận Nộp bài</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
