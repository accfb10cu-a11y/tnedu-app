import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { CheckCircle2, Sparkles, Send } from 'lucide-react';
import { UserProfile } from '../types';

interface CelebrationOverlayProps {
  user: UserProfile;
  onComplete: () => void;
}

export const CelebrationOverlay: React.FC<CelebrationOverlayProps> = ({ user, onComplete }) => {
  const [countdown, setCountdown] = useState(3);
  const [progress, setProgress] = useState(100);

  useEffect(() => {
    const totalDuration = 3000;
    const intervalTime = 50;
    const step = (intervalTime / totalDuration) * 100;

    const progressTimer = setInterval(() => {
      setProgress((prev) => Math.max(0, prev - step));
    }, intervalTime);

    const countTimer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(countTimer);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    const finishTimer = setTimeout(() => {
      onComplete();
    }, totalDuration);

    return () => {
      clearInterval(progressTimer);
      clearInterval(countTimer);
      clearTimeout(finishTimer);
    };
  }, [onComplete]);

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-md p-4">
        {/* Festive Floating Background Bubbles */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          {[...Array(12)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute rounded-full bg-emerald-400/20"
              style={{
                width: Math.random() * 80 + 20,
                height: Math.random() * 80 + 20,
                left: `${(i * 9) % 100}%`,
                top: `${(i * 13) % 100}%`,
              }}
              animate={{
                y: [-20, 20, -20],
                opacity: [0.3, 0.7, 0.3],
                scale: [0.8, 1.2, 0.8],
              }}
              transition={{
                duration: 3 + (i % 3),
                repeat: Infinity,
                ease: 'easeInOut',
              }}
            />
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, scale: 0.85, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.9, y: -20 }}
          transition={{ type: 'spring', damping: 25, stiffness: 300 }}
          className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl p-8 border border-emerald-100 text-center overflow-hidden"
        >
          {/* Top highlight banner */}
          <div className="absolute top-0 left-0 right-0 h-2 bg-gradient-to-r from-emerald-400 via-teal-500 to-emerald-600" />

          {/* Success Icon with glowing ring */}
          <div className="relative mx-auto mb-6 flex items-center justify-center w-24 h-24">
            <motion.div
              animate={{ scale: [1, 1.15, 1], rotate: [0, 5, -5, 0] }}
              transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
              className="absolute inset-0 rounded-full bg-emerald-100/80 animate-ping opacity-25"
            />
            <div className="w-20 h-20 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-400 flex items-center justify-center text-white shadow-lg shadow-emerald-500/30">
              <CheckCircle2 className="w-10 h-10" />
            </div>
            <div className="absolute -top-1 -right-1 p-1.5 bg-amber-400 text-white rounded-full shadow-md animate-bounce">
              <Sparkles className="w-4 h-4" />
            </div>
          </div>

          {/* Congratulations Greeting */}
          <h2 className="text-2xl font-bold text-slate-800 tracking-tight">
            Đăng Nhập Thành Công!
          </h2>
          <p className="mt-2 text-base text-emerald-700 font-semibold">
            Xin chào, {user.full_name || user.email}!
          </p>
          <p className="mt-1 text-sm text-slate-500">
            Chào mừng bạn đến với hệ thống nộp bài <span className="font-bold text-emerald-700">TNedu</span>. Đang chuẩn bị không gian làm việc...
          </p>

          {/* Countdown & Progress */}
          <div className="mt-8 space-y-3">
            <div className="flex items-center justify-between text-xs font-medium text-slate-500">
              <span className="flex items-center gap-1.5 text-emerald-600">
                <Send className="w-3.5 h-3.5 animate-pulse" />
                Chuyển trang sau
              </span>
              <span className="font-bold text-slate-700 text-sm">{countdown}s</span>
            </div>

            {/* Smooth animated progress bar */}
            <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden p-0.5 border border-slate-200">
              <div
                className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 rounded-full transition-all duration-75 ease-linear"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>

          <button
            onClick={onComplete}
            className="mt-6 w-full py-2.5 px-4 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-medium text-sm rounded-xl transition-colors cursor-pointer border border-emerald-200"
          >
            Vào trang nộp bài ngay →
          </button>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
