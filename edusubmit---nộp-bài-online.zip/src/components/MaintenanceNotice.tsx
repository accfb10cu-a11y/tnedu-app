import React from 'react';
import { Wrench, AlertTriangle, ShieldCheck, Clock } from 'lucide-react';
import { SystemSettings } from '../types';

interface MaintenanceNoticeProps {
  settings: SystemSettings;
  onAdminLogin: () => void;
}

export const MaintenanceNotice: React.FC<MaintenanceNoticeProps> = ({ settings, onAdminLogin }) => {
  return (
    <div className="min-h-[80vh] flex items-center justify-center p-4">
      <div className="max-w-md w-full bg-white rounded-3xl shadow-xl border border-amber-200 p-8 text-center relative overflow-hidden">
        <div className="absolute top-0 left-0 right-0 h-2 bg-gradient-to-r from-amber-400 via-orange-500 to-amber-600" />

        <div className="w-20 h-20 mx-auto mb-6 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center border border-amber-100 shadow-inner">
          <Wrench className="w-10 h-10 animate-bounce" />
        </div>

        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-100 text-amber-800 text-xs font-semibold mb-3">
          <AlertTriangle className="w-3.5 h-3.5" />
          Hệ Thống Đang Bảo Trì Định Kỳ
        </div>

        <h2 className="text-2xl font-bold text-slate-800 tracking-tight">
          Tạm Thời Ngừng Tiếp Nhận Bài
        </h2>

        <p className="mt-3 text-sm text-slate-600 leading-relaxed">
          {settings.maintenance_message || 'Hệ thống đang được nâng cấp để tối ưu hóa hiệu suất và bảo mật. Vui lòng quay lại sau ít phút.'}
        </p>

        <div className="mt-6 p-4 bg-slate-50 rounded-2xl border border-slate-200 text-xs text-slate-500 flex items-center justify-center gap-2">
          <Clock className="w-4 h-4 text-slate-400" />
          <span>Thời gian dự kiến hoàn tất: Sớm nhất có thể</span>
        </div>
      </div>
    </div>
  );
};
