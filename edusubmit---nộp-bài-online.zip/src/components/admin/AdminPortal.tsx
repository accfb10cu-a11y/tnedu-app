import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, 
  Users, 
  FileText, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  Trash2, 
  Lock, 
  Unlock, 
  Search, 
  Filter, 
  AlertTriangle, 
  Eye, 
  EyeOff,
  ExternalLink, 
  FileDown, 
  Wrench, 
  BarChart3, 
  TrendingUp, 
  LogOut, 
  ArrowLeft,
  RefreshCw,
  MessageSquare,
  ShieldAlert,
  Calendar,
  Mail,
  UserCheck,
  Key,
  Copy,
  Info,
  Database,
  FileCode,
  Check,
  Gift,
  Plus,
  Coins,
  Sparkles,
  Edit,
  RotateCcw
} from 'lucide-react';
import { Submission, UserProfile, SystemSettings, SubmissionStatus, Role, LuckyGift } from '../../types';
import { dbService } from '../../services/db';
import { getSupabaseConfig, saveSupabaseConfig, isValidSupabaseUrl } from '../../lib/supabase';

interface AdminPortalProps {
  currentUser: UserProfile | null;
  onLogout: () => void;
  onBackToMemberArea: () => void;
  onLoginAsAdmin: (user: UserProfile) => void;
}

interface ConfirmDialogState {
  isOpen: boolean;
  title: string;
  message: string;
  confirmText?: string;
  isDangerous?: boolean;
  onConfirm: () => void;
}

export const AdminPortal: React.FC<AdminPortalProps> = ({
  currentUser,
  onLogout,
  onBackToMemberArea,
  onLoginAsAdmin,
}) => {
  const [activeTab, setActiveTab] = useState<'stats' | 'submissions' | 'users' | 'gifts' | 'settings'>('stats');
  
  // Lucky Gifts States
  const [luckyGifts, setLuckyGifts] = useState<LuckyGift[]>([]);
  const [editingGift, setEditingGift] = useState<LuckyGift | null>(null);
  const [isGiftModalOpen, setIsGiftModalOpen] = useState(false);
  const [giftFormName, setGiftFormName] = useState('');
  const [giftFormAmount, setGiftFormAmount] = useState(10000);
  const [giftFormProb, setGiftFormProb] = useState(20);
  const [giftFormActive, setGiftFormActive] = useState(true);
  const [giftFormDesc, setGiftFormDesc] = useState('');

  // Supabase connection state inside Admin Portal
  const initialSupabaseConfig = getSupabaseConfig();
  const [supabaseUrl, setSupabaseUrl] = useState(initialSupabaseConfig.url);
  const [supabaseAnonKey, setSupabaseAnonKey] = useState(initialSupabaseConfig.anonKey);
  const [supabaseConfigured, setSupabaseConfigured] = useState(initialSupabaseConfig.isConfigured);
  const [copiedSql, setCopiedSql] = useState(false);
  const [showSqlSchema, setShowSqlSchema] = useState(false);

  // Data states
  const [submissions, setSubmissions] = useState<Submission[]>([]);
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [settings, setSettings] = useState<SystemSettings>({
    is_maintenance: false,
    maintenance_message: '',
    allow_new_submissions: true,
    max_file_size_mb: 25,
    allowed_file_types: 'pdf,docx,zip,rar,png,jpg,jpeg',
  });
  const [loading, setLoading] = useState(true);

  // Submissions search & filters
  const [subSearch, setSubSearch] = useState('');
  const [subStatusFilter, setSubStatusFilter] = useState<'all' | SubmissionStatus>('all');
  const [selectedSub, setSelectedSub] = useState<Submission | null>(null);

  // Reject Modal state
  const [rejectingSub, setRejectingSub] = useState<Submission | null>(null);
  const [rejectionReason, setRejectionReason] = useState('');
  const [rejectionError, setRejectionError] = useState<string | null>(null);

  // Approve Modal state
  const [approvingSub, setApprovingSub] = useState<Submission | null>(null);
  const [approveFeedback, setApproveFeedback] = useState('Bài làm rất tốt, đáp ứng đúng yêu cầu của đề tài.');

  // User search & View state
  const [userSearch, setUserSearch] = useState('');
  const [showPasswordMap, setShowPasswordMap] = useState<Record<string, boolean>>({});
  const [selectedUserDetail, setSelectedUserDetail] = useState<UserProfile | null>(null);

  // In-App Confirm Dialog (Replaces window.confirm which is blocked in iframes!)
  const [confirmDialog, setConfirmDialog] = useState<ConfirmDialogState | null>(null);

  // Admin Login state if not logged in as admin
  const [adminEmail, setAdminEmail] = useState('admin@tnedu.vn');
  const [adminPassword, setAdminPassword] = useState('admin123');
  const [loginError, setLoginError] = useState<string | null>(null);
  const [loggingIn, setLoggingIn] = useState(false);

  // Notification toast
  const [toast, setToast] = useState<{ msg: string; type: 'success' | 'error' } | null>(null);

  const showToast = (msg: string, type: 'success' | 'error' = 'success') => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3000);
  };

  const loadAllData = async () => {
    setLoading(true);
    try {
      const [subsData, usersData, settingsData, giftsData] = await Promise.all([
        dbService.getAllSubmissions(),
        dbService.getAllUsers(),
        dbService.getSystemSettings(),
        dbService.getLuckyGifts(),
      ]);
      setSubmissions(subsData);
      setUsers(usersData);
      setSettings(settingsData);
      setLuckyGifts(giftsData);
    } catch (err) {
      console.error('Error loading admin data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (currentUser && currentUser.role === 'admin') {
      loadAllData();
    }
  }, [currentUser]);

  // Handle direct Admin Login at /#adminbas
  const handleAdminLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);
    setLoggingIn(true);
    try {
      const user = await dbService.login(adminEmail, adminPassword);
      if (user.role !== 'admin') {
        throw new Error('Tài khoản này không có quyền Quản trị viên (Admin).');
      }
      onLoginAsAdmin(user);
    } catch (err: any) {
      setLoginError(err?.message || 'Đăng nhập không thành công.');
    } finally {
      setLoggingIn(false);
    }
  };

  // If not logged in or not admin, show protection gate at /#adminbas
  if (!currentUser || currentUser.role !== 'admin') {
    return (
      <div className="min-h-screen bg-slate-900 text-slate-100 flex items-center justify-center p-4">
        <div className="max-w-md w-full bg-slate-800 border border-slate-700 rounded-3xl p-8 shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-emerald-500 to-teal-400" />

          <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30">
            <ShieldCheck className="w-8 h-8" />
          </div>

          <h2 className="text-2xl font-extrabold text-center text-white tracking-tight">
            Cổng Quản Trị Hệ Thống TNedu
          </h2>
          <p className="text-xs text-slate-400 text-center mt-1 mb-6">
            Đường dẫn quản trị bảo mật (/#adminbas)
          </p>

          {currentUser && currentUser.role !== 'admin' && (
            <div className="mb-6 p-4 bg-rose-500/20 border border-rose-500/40 rounded-2xl text-xs text-rose-300 space-y-2">
              <div className="flex items-start gap-2.5">
                <ShieldAlert className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <div>
                  <p className="font-bold">Truy cập bị từ chối</p>
                  <p className="mt-0.5">
                    Tài khoản ({currentUser.email}) không có quyền Quản trị viên.
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={onLogout}
                className="w-full py-2 bg-rose-600/40 hover:bg-rose-600 text-rose-100 rounded-xl font-semibold transition-colors cursor-pointer"
              >
                Đăng xuất tài khoản này để đăng nhập Admin
              </button>
            </div>
          )}

          {loginError && (
            <div className="mb-4 p-3 bg-rose-500/20 border border-rose-500/40 rounded-xl text-xs text-rose-300">
              {loginError}
            </div>
          )}

          <form onSubmit={handleAdminLoginSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Email Quản Trị Viên
              </label>
              <input
                type="email"
                required
                value={adminEmail}
                onChange={(e) => setAdminEmail(e.target.value)}
                className="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-sm text-white focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Mật khẩu Quản Trị
              </label>
              <input
                type="password"
                required
                value={adminPassword}
                onChange={(e) => setAdminPassword(e.target.value)}
                className="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-sm text-white focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
              />
            </div>

            <button
              type="submit"
              disabled={loggingIn}
              className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm rounded-xl transition-all shadow-lg shadow-emerald-900/50 cursor-pointer disabled:opacity-50"
            >
              {loggingIn ? 'Đang xác thực...' : 'Đăng nhập Quản Trị Viên'}
            </button>

            {/* Quick 1-click Admin Login button */}
            <button
              type="button"
              disabled={loggingIn}
              onClick={async () => {
                setAdminEmail('admin@tnedu.vn');
                setAdminPassword('admin123');
                setLoggingIn(true);
                try {
                  const user = await dbService.login('admin@tnedu.vn', 'admin123');
                  onLoginAsAdmin(user);
                } catch (err: any) {
                  setLoginError(err?.message || 'Đăng nhập không thành công.');
                } finally {
                  setLoggingIn(false);
                }
              }}
              className="w-full py-2.5 bg-slate-900/80 hover:bg-slate-900 border border-emerald-500/40 text-emerald-300 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5"
            >
              <span>⚡ Đăng nhập nhanh Admin (admin@tnedu.vn / admin123)</span>
            </button>
          </form>

          <div className="mt-6 pt-6 border-t border-slate-700/60 flex items-center justify-between text-xs text-slate-400">
            <button
              onClick={onBackToMemberArea}
              className="hover:text-emerald-400 flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Quay lại trang học viên</span>
            </button>

            <span className="text-[11px] text-slate-400">Mặc định: admin@tnedu.vn</span>
          </div>
        </div>
      </div>
    );
  }

  // Admin Actions: Approve
  const handleConfirmApprove = async () => {
    if (!approvingSub) return;
    try {
      await dbService.updateSubmissionStatus(
        approvingSub.id,
        'approved',
        approveFeedback.trim(),
        currentUser.full_name || 'Admin'
      );
      showToast('Đã phê duyệt bài nộp thành công!');
      setApprovingSub(null);
      loadAllData();
    } catch (err: any) {
      showToast(err?.message || 'Lỗi khi phê duyệt bài', 'error');
    }
  };

  // Admin Actions: Reject (Mandatory reason)
  const handleConfirmReject = async () => {
    if (!rejectingSub) return;
    if (!rejectionReason.trim()) {
      setRejectionError('Bắt buộc phải ghi rõ lý do khi từ chối bài nộp của học viên.');
      return;
    }

    try {
      await dbService.updateSubmissionStatus(
        rejectingSub.id,
        'rejected',
        rejectionReason.trim(),
        currentUser.full_name || 'Admin'
      );
      showToast('Đã từ chối bài nộp và gửi lý do cho học viên.');
      setRejectingSub(null);
      setRejectionReason('');
      setRejectionError(null);
      loadAllData();
    } catch (err: any) {
      setRejectionError(err?.message || 'Lỗi khi từ chối bài');
    }
  };

  // Admin Actions: Delete Submission with in-app confirmation
  const requestDeleteSubmission = (sub: Submission) => {
    setConfirmDialog({
      isOpen: true,
      title: 'Xóa bài nộp vĩnh viễn',
      message: `Bạn có chắc chắn muốn xóa bài nộp "${sub.title}" của học viên ${sub.user_name}? Thao tác này sẽ xóa bài và tệp đính kèm.`,
      confirmText: 'Xóa bài nộp',
      isDangerous: true,
      onConfirm: async () => {
        try {
          await dbService.deleteSubmission(sub.id);
          showToast('Đã xóa bài nộp thành công!');
          if (selectedSub?.id === sub.id) {
            setSelectedSub(null);
          }
          await loadAllData();
        } catch (err: any) {
          showToast(err?.message || 'Lỗi khi xóa bài nộp', 'error');
        } finally {
          setConfirmDialog(null);
        }
      },
    });
  };

  // Admin User Actions: Lock / Unlock with in-app confirmation
  const requestToggleLockUser = (user: UserProfile) => {
    const isLocking = !user.is_locked;
    setConfirmDialog({
      isOpen: true,
      title: isLocking ? 'Khóa tài khoản thành viên' : 'Mở khóa tài khoản',
      message: isLocking
        ? `Khóa tài khoản ${user.full_name} (${user.email}). Người dùng sẽ không thể đăng nhập hoặc nộp bài mới.`
        : `Mở khóa tài khoản ${user.full_name} (${user.email}). Người dùng có thể tiếp tục truy cập hệ thống.`,
      confirmText: isLocking ? 'Xác nhận Khóa' : 'Xác nhận Mở khóa',
      isDangerous: isLocking,
      onConfirm: async () => {
        try {
          await dbService.setUserLockStatus(user.id, isLocking);
          showToast(`Đã ${isLocking ? 'khóa' : 'mở khóa'} tài khoản thành công!`);
          await loadAllData();
        } catch (err: any) {
          showToast(err?.message || 'Lỗi thao tác tài khoản', 'error');
        } finally {
          setConfirmDialog(null);
        }
      },
    });
  };

  // Admin User Actions: Delete User with in-app confirmation
  const requestDeleteUser = (user: UserProfile) => {
    if (user.id === currentUser.id) {
      showToast('Không thể tự xóa tài khoản quản trị đang đăng nhập.', 'error');
      return;
    }

    setConfirmDialog({
      isOpen: true,
      title: 'Xóa tài khoản người dùng',
      message: `Cảnh báo: Bạn đang thực hiện xóa tài khoản "${user.full_name}" (${user.email}). Toàn bộ bài nộp và dữ liệu liên quan sẽ bị dọn dẹp vĩnh viễn.`,
      confirmText: 'Xóa người dùng & bài nộp',
      isDangerous: true,
      onConfirm: async () => {
        try {
          await dbService.deleteUser(user.id);
          showToast('Đã xóa tài khoản và toàn bộ dữ liệu thành công!');
          if (selectedUserDetail?.id === user.id) {
            setSelectedUserDetail(null);
          }
          await loadAllData();
        } catch (err: any) {
          showToast(err?.message || 'Lỗi khi xóa người dùng', 'error');
        } finally {
          setConfirmDialog(null);
        }
      },
    });
  };

  // Admin User Actions: Toggle Role
  const handleToggleRole = async (user: UserProfile) => {
    if (user.id === currentUser.id) {
      showToast('Không thể tự thay đổi vai trò của chính bạn.', 'error');
      return;
    }
    const newRole: Role = user.role === 'admin' ? 'user' : 'admin';
    try {
      await dbService.updateUserRole(user.id, newRole);
      showToast(`Đã chuyển vai trò thành ${newRole === 'admin' ? 'Quản trị viên' : 'Học viên'}!`);
      loadAllData();
    } catch (err: any) {
      showToast(err?.message || 'Lỗi khi thay đổi quyền', 'error');
    }
  };

  // Maintenance Toggle
  const handleToggleMaintenance = async () => {
    try {
      const updated = await dbService.updateSystemSettings({
        is_maintenance: !settings.is_maintenance,
      });
      setSettings(updated);
      showToast(
        updated.is_maintenance
          ? 'Đã BẬT chế độ bảo trì hệ thống!'
          : 'Đã TẮT chế độ bảo trì, hệ thống hoạt động bình thường!'
      );
    } catch (err: any) {
      showToast('Không thể cập nhật trạng thái bảo trì', 'error');
    }
  };

  // Save Maintenance Message
  const handleSaveMaintenanceMessage = async (msg: string) => {
    try {
      const updated = await dbService.updateSystemSettings({
        maintenance_message: msg,
      });
      setSettings(updated);
      showToast('Đã cập nhật thông điệp bảo trì!');
    } catch (err) {
      showToast('Lỗi lưu cài đặt', 'error');
    }
  };

  // Supabase Configuration Handlers (Strictly within Admin Portal)
  const handleSaveSupabase = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanUrl = supabaseUrl.trim();
    const cleanKey = supabaseAnonKey.trim();

    if (cleanUrl && !isValidSupabaseUrl(cleanUrl)) {
      showToast('URL Supabase không hợp lệ! Cần có dạng https://xxxx.supabase.co', 'error');
      return;
    }

    saveSupabaseConfig(cleanUrl, cleanKey);
    const updated = getSupabaseConfig();
    setSupabaseConfigured(updated.isConfigured);
    showToast(updated.isConfigured ? 'Đã lưu và kích hoạt kết nối Supabase Cloud!' : 'Đã lưu cấu hình!');
    loadAllData();
  };

  const handleClearSupabase = () => {
    saveSupabaseConfig('', '');
    setSupabaseUrl('');
    setSupabaseAnonKey('');
    setSupabaseConfigured(false);
    showToast('Đã chuyển về Local Storage Engine an toàn!');
    loadAllData();
  };

  const handleCopySqlSchema = () => {
    const sqlCode = `-- ==============================================================================
-- TNedu - SUPABASE POSTGRESQL SCHEMA & ROW LEVEL SECURITY (RLS) POLICIES
-- ==============================================================================
-- 1. BẢNG PROFILES
create table if not exists public.profiles (
  id uuid references auth.users on delete cascade primary key,
  email text not null,
  full_name text not null,
  role text not null default 'user' check (role in ('user', 'admin')),
  is_locked boolean not null default false,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  updated_at timestamp with time zone default timezone('utc'::text, now()) not null
);
alter table public.profiles enable row level security;

create or replace function public.is_admin()
returns boolean as $$
begin
  return exists (select 1 from public.profiles where id = auth.uid() and role = 'admin');
end;
$$ language plpgsql security definer;

create policy "Users can view own profile or admin view all"
  on public.profiles for select using (auth.uid() = id or public.is_admin());
create policy "Users can update own profile"
  on public.profiles for update using (auth.uid() = id) with check (auth.uid() = id);
create policy "Admin can update any profile"
  on public.profiles for update using (public.is_admin());
create policy "Admin can delete profile"
  on public.profiles for delete using (public.is_admin());

-- 2. BẢNG SUBMISSIONS
create table if not exists public.submissions (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references public.profiles(id) on delete cascade not null,
  user_name text not null,
  user_email text not null,
  title text not null,
  content text not null,
  link_url text,
  file_name text,
  file_size bigint,
  file_type text,
  file_url text,
  file_path text,
  status text not null default 'pending' check (status in ('pending', 'approved', 'rejected')),
  admin_feedback text,
  reviewed_by text,
  reviewed_at timestamp with time zone,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  updated_at timestamp with time zone default timezone('utc'::text, now()) not null
);
alter table public.submissions enable row level security;

create policy "Users view own submissions, Admin view all"
  on public.submissions for select using (auth.uid() = user_id or public.is_admin());
create policy "Users can insert own submissions"
  on public.submissions for insert with check (auth.uid() = user_id);
create policy "Admin can update submissions"
  on public.submissions for update using (public.is_admin());
create policy "Admin can delete submissions"
  on public.submissions for delete using (public.is_admin());

-- 3. BẢNG SYSTEM_SETTINGS
create table if not exists public.system_settings (
  id text primary key default 'global',
  is_maintenance boolean not null default false,
  maintenance_message text not null default 'Hệ thống đang bảo trì nâng cấp định kỳ. Vui lòng quay lại sau.',
  allow_new_submissions boolean not null default true,
  max_file_size_mb integer not null default 25,
  allowed_file_types text not null default 'pdf,docx,zip,rar,png,jpg,jpeg',
  updated_at timestamp with time zone default timezone('utc'::text, now()) not null
);
alter table public.system_settings enable row level security;
create policy "Everyone can view settings" on public.system_settings for select using (true);
create policy "Only admin can update settings" on public.system_settings for update using (public.is_admin());
insert into public.system_settings (id, is_maintenance) values ('global', false) on conflict do nothing;

-- 4. BẢO MẬT STORAGE (Private Bucket)
insert into storage.buckets (id, name, public) values ('submissions', 'submissions', false) on conflict do update set public = false;
create policy "Users upload to own folder" on storage.objects for insert with check (bucket_id = 'submissions' and (auth.uid())::text = (storage.foldername(name))[1]);
create policy "Users view own files, Admin view all" on storage.objects for select using (bucket_id = 'submissions' and ((auth.uid())::text = (storage.foldername(name))[1] or public.is_admin()));
create policy "Admin delete files" on storage.objects for delete using (bucket_id = 'submissions' and public.is_admin());

-- 5. TRIGGER AUTH SYNC
create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, email, full_name, role)
  values (new.id, new.email, coalesce(new.raw_user_meta_data->>'full_name', split_part(new.email, '@', 1)), case when new.email like 'admin%' then 'admin' else 'user' end);
  return new;
end;
$$ language plpgsql security definer;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();`;

    navigator.clipboard.writeText(sqlCode);
    setCopiedSql(true);
    showToast('Đã sao chép mã SQL Supabase & RLS Policies!');
    setTimeout(() => setCopiedSql(false), 2000);
  };

  // LUCKY GIFTS ACTIONS (Quản lý quà tặng may mắn)
  const handleToggleGift = async (gift: LuckyGift) => {
    try {
      const updated = await dbService.toggleLuckyGift(gift.id);
      setLuckyGifts(updated);
      showToast(gift.is_active ? `Đã TẮT phần quà "${gift.name}"` : `Đã BẬT phần quà "${gift.name}"`);
    } catch {
      showToast('Lỗi khi thay đổi trạng thái quà', 'error');
    }
  };

  const handleOpenAddGift = () => {
    setEditingGift(null);
    setGiftFormName('');
    setGiftFormAmount(20000);
    setGiftFormProb(20);
    setGiftFormActive(true);
    setGiftFormDesc('');
    setIsGiftModalOpen(true);
  };

  const handleOpenEditGift = (gift: LuckyGift) => {
    setEditingGift(gift);
    setGiftFormName(gift.name);
    setGiftFormAmount(gift.amount);
    setGiftFormProb(gift.probability);
    setGiftFormActive(gift.is_active);
    setGiftFormDesc(gift.description || '');
    setIsGiftModalOpen(true);
  };

  const handleSaveGiftSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!giftFormName.trim()) {
      showToast('Vui lòng nhập tên phần quà!', 'error');
      return;
    }

    const giftToSave: LuckyGift = {
      id: editingGift ? editingGift.id : 'gift_' + Date.now().toString(36),
      name: giftFormName.trim(),
      amount: Number(giftFormAmount) || 0,
      probability: Math.max(0, Number(giftFormProb) || 0),
      is_active: giftFormActive,
      description: giftFormDesc.trim(),
    };

    try {
      const updated = await dbService.saveLuckyGift(giftToSave);
      setLuckyGifts(updated);
      setIsGiftModalOpen(false);
      showToast(editingGift ? 'Đã cập nhật phần quà!' : 'Đã thêm phần quà mới thành công!');
    } catch {
      showToast('Lỗi khi lưu phần quà', 'error');
    }
  };

  const requestDeleteGift = (gift: LuckyGift) => {
    setConfirmDialog({
      isOpen: true,
      title: 'Xóa phần quà này?',
      message: `Bạn có chắc muốn xóa phần quà "${gift.name}" (${new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(gift.amount)})?`,
      confirmText: 'Xác nhận Xóa',
      isDangerous: true,
      onConfirm: async () => {
        try {
          const updated = await dbService.deleteLuckyGift(gift.id);
          setLuckyGifts(updated);
          showToast('Đã xóa phần quà thành công!');
        } catch {
          showToast('Lỗi khi xóa phần quà', 'error');
        } finally {
          setConfirmDialog(null);
        }
      },
    });
  };

  const handleResetGifts = () => {
    setConfirmDialog({
      isOpen: true,
      title: 'Khôi phục danh sách quà mẫu?',
      message: 'Danh sách các phần quà sẽ được đưa về 5 phần quà lì xì mặc định của hệ thống TNedu.',
      confirmText: 'Khôi phục',
      isDangerous: false,
      onConfirm: async () => {
        const reseted = await dbService.resetLuckyGifts();
        setLuckyGifts(reseted);
        showToast('Đã khôi phục các phần quà mặc định!');
        setConfirmDialog(null);
      },
    });
  };

  // Toggle visible password in table
  const toggleShowPassword = (userId: string) => {
    setShowPasswordMap((prev) => ({
      ...prev,
      [userId]: !prev[userId],
    }));
  };

  // Copy password helper
  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    showToast(`Đã sao chép ${label}!`);
  };

  // Filtered Submissions
  const filteredSubmissions = submissions.filter((s) => {
    const matchSearch =
      s.title.toLowerCase().includes(subSearch.toLowerCase()) ||
      s.user_name.toLowerCase().includes(subSearch.toLowerCase()) ||
      s.user_email.toLowerCase().includes(subSearch.toLowerCase()) ||
      s.content.toLowerCase().includes(subSearch.toLowerCase());
    const matchStatus = subStatusFilter === 'all' || s.status === subStatusFilter;
    return matchSearch && matchStatus;
  });

  // Filtered Users
  const filteredUsers = users.filter((u) => {
    return (
      u.full_name.toLowerCase().includes(userSearch.toLowerCase()) ||
      u.email.toLowerCase().includes(userSearch.toLowerCase()) ||
      u.id.toLowerCase().includes(userSearch.toLowerCase())
    );
  });

  // Analytics Stats
  const totalSubmissions = submissions.length;
  const pendingCount = submissions.filter((s) => s.status === 'pending').length;
  const approvedCount = submissions.filter((s) => s.status === 'approved').length;
  const rejectedCount = submissions.filter((s) => s.status === 'rejected').length;
  const approvalRate = totalSubmissions > 0 ? Math.round((approvedCount / totalSubmissions) * 100) : 0;

  const downloadFile = (sub: Submission) => {
    if (!sub.file?.url) return;
    const link = document.createElement('a');
    link.href = sub.file.url;
    link.download = sub.file.name;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col font-sans">
      {/* Toast Notification */}
      {toast && (
        <div className={`fixed top-4 right-4 z-50 px-4 py-3 rounded-2xl shadow-xl text-xs font-bold border flex items-center gap-2 animate-bounce ${
          toast.type === 'success' 
            ? 'bg-emerald-950 text-emerald-300 border-emerald-500/50' 
            : 'bg-rose-950 text-rose-300 border-rose-500/50'
        }`}>
          {toast.type === 'success' ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <AlertTriangle className="w-4 h-4 text-rose-400" />}
          <span>{toast.msg}</span>
        </div>
      )}

      {/* Admin Top Navbar */}
      <header className="bg-slate-800/90 backdrop-blur-md border-b border-slate-700/80 sticky top-0 z-30 px-4 sm:px-8 py-3.5">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <span className="font-extrabold text-white tracking-tight flex items-center gap-2 text-sm sm:text-base">
                TNedu Admin Portal
                <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 text-[10px] font-mono border border-emerald-500/30">
                  /#adminbas
                </span>
              </span>
              <p className="text-[11px] text-slate-400">
                Hệ thống Quản trị & Phê duyệt bài nộp TNedu
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Maintenance indicator badge */}
            <div className={`hidden sm:flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold border ${
              settings.is_maintenance
                ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                : 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
            }`}>
              <span className={`w-2 h-2 rounded-full ${settings.is_maintenance ? 'bg-amber-400 animate-ping' : 'bg-emerald-400'}`} />
              <span>{settings.is_maintenance ? 'Bảo trì: BẬT' : 'Hệ thống: HOẠT ĐỘNG'}</span>
            </div>

            <button
              onClick={onBackToMemberArea}
              className="px-3.5 py-1.5 rounded-xl bg-slate-700 hover:bg-slate-600 text-slate-200 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Quay lại trang học viên</span>
            </button>

            <button
              onClick={onLogout}
              className="p-2 text-slate-400 hover:text-rose-400 hover:bg-rose-950/40 rounded-xl transition-colors cursor-pointer"
              title="Đăng xuất"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      {/* Main Admin Container */}
      <div className="max-w-7xl mx-auto w-full px-4 sm:px-8 py-6 flex-1 space-y-6">
        {/* Navigation Tabs */}
        <div className="flex items-center gap-2 border-b border-slate-700/80 pb-3 overflow-x-auto">
          <button
            onClick={() => setActiveTab('stats')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'stats'
                ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-950'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <BarChart3 className="w-4 h-4" />
            <span>Thống Kê Tổng Quan</span>
          </button>

          <button
            onClick={() => setActiveTab('submissions')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'submissions'
                ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-950'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>Quản Lý Bài Nộp ({submissions.length})</span>
            {pendingCount > 0 && (
              <span className="px-1.5 py-0.5 rounded-full bg-amber-400 text-slate-900 text-[10px] font-extrabold">
                {pendingCount}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('users')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'users'
                ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-950'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>Quản Lý Tài Khoản & Mật Khẩu ({users.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('gifts')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'gifts'
                ? 'bg-amber-400 text-slate-950 shadow-lg shadow-amber-950'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Gift className="w-4 h-4 text-amber-400" />
            <span>Hộp Quà May Mắn ({luckyGifts.filter((g) => g.is_active).length}/{luckyGifts.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('settings')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'settings'
                ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-950'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Wrench className="w-4 h-4" />
            <span>Cài Đặt & Bảo Trì</span>
          </button>

          <button
            onClick={loadAllData}
            title="Tải lại dữ liệu"
            className="ml-auto p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl transition-colors cursor-pointer"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>

        {/* TAB 1: STATISTICS */}
        {activeTab === 'stats' && (
          <div className="space-y-6">
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-slate-800 border border-slate-700 rounded-2xl p-5 space-y-2">
                <div className="flex items-center justify-between text-slate-400 text-xs">
                  <span>Tổng bài nộp</span>
                  <FileText className="w-4 h-4 text-emerald-400" />
                </div>
                <p className="text-3xl font-extrabold text-white tracking-tight">{totalSubmissions}</p>
                <p className="text-[11px] text-slate-500">Từ tất cả học viên trong hệ thống</p>
              </div>

              <div className="bg-slate-800 border border-amber-500/30 rounded-2xl p-5 space-y-2">
                <div className="flex items-center justify-between text-amber-400 text-xs font-semibold">
                  <span>Chờ phê duyệt</span>
                  <Clock className="w-4 h-4 text-amber-400 animate-spin" />
                </div>
                <p className="text-3xl font-extrabold text-amber-400 tracking-tight">{pendingCount}</p>
                <button
                  onClick={() => {
                    setActiveTab('submissions');
                    setSubStatusFilter('pending');
                  }}
                  className="text-[11px] text-amber-300/80 hover:text-amber-300 underline cursor-pointer"
                >
                  Xử lý ngay →
                </button>
              </div>

              <div className="bg-slate-800 border border-emerald-500/30 rounded-2xl p-5 space-y-2">
                <div className="flex items-center justify-between text-emerald-400 text-xs font-semibold">
                  <span>Đã duyệt (Đạt)</span>
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                </div>
                <p className="text-3xl font-extrabold text-emerald-400 tracking-tight">{approvedCount}</p>
                <p className="text-[11px] text-emerald-300/80">Tỷ lệ duyệt: {approvalRate}%</p>
              </div>

              <div className="bg-slate-800 border border-rose-500/30 rounded-2xl p-5 space-y-2">
                <div className="flex items-center justify-between text-rose-400 text-xs font-semibold">
                  <span>Bị từ chối</span>
                  <XCircle className="w-4 h-4 text-rose-400" />
                </div>
                <p className="text-3xl font-extrabold text-rose-400 tracking-tight">{rejectedCount}</p>
                <p className="text-[11px] text-rose-300/80">Đã gửi kèm lý do chỉnh sửa</p>
              </div>
            </div>

            {/* Quick Actions & Pending List preview */}
            <div className="bg-slate-800 border border-slate-700 rounded-3xl p-6 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-base text-white">Bài nộp đang chờ duyệt cần xử lý</h3>
                  <p className="text-xs text-slate-400">Các bài tập học viên mới gửi gần đây nhất</p>
                </div>
                <button
                  onClick={() => {
                    setActiveTab('submissions');
                    setSubStatusFilter('pending');
                  }}
                  className="text-xs font-bold text-emerald-400 hover:text-emerald-300 cursor-pointer"
                >
                  Xem toàn bộ ({pendingCount}) →
                </button>
              </div>

              {submissions.filter((s) => s.status === 'pending').length === 0 ? (
                <div className="py-8 text-center text-slate-400 text-xs">
                  🎉 Hiện không còn bài nộp nào đang chờ duyệt.
                </div>
              ) : (
                <div className="space-y-3">
                  {submissions
                    .filter((s) => s.status === 'pending')
                    .slice(0, 3)
                    .map((item) => (
                      <div
                        key={item.id}
                        className="p-4 bg-slate-900/60 rounded-2xl border border-slate-700/80 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3"
                      >
                        <div>
                          <h4 className="font-bold text-sm text-slate-200">{item.title}</h4>
                          <p className="text-xs text-slate-400 mt-0.5">
                            Học viên: <span className="text-slate-300 font-semibold">{item.user_name}</span> ({item.user_email})
                          </p>
                        </div>
                        <div className="flex items-center gap-2 self-end sm:self-auto">
                          <button
                            onClick={() => setSelectedSub(item)}
                            className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-xs text-slate-200 rounded-xl cursor-pointer"
                          >
                            Xem bài
                          </button>
                          <button
                            onClick={() => setApprovingSub(item)}
                            className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-xs font-bold text-white rounded-xl shadow-xs cursor-pointer"
                          >
                            Duyệt
                          </button>
                          <button
                            onClick={() => {
                              setRejectingSub(item);
                              setRejectionReason('');
                              setRejectionError(null);
                            }}
                            className="px-3 py-1.5 bg-rose-600/80 hover:bg-rose-600 text-xs font-bold text-white rounded-xl cursor-pointer"
                          >
                            Từ chối
                          </button>
                          <button
                            onClick={() => requestDeleteSubmission(item)}
                            title="Xóa bài nộp"
                            className="p-1.5 bg-slate-800 hover:bg-rose-950/60 text-slate-400 hover:text-rose-400 rounded-xl cursor-pointer"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 2: SUBMISSIONS MANAGEMENT */}
        {activeTab === 'submissions' && (
          <div className="space-y-4">
            {/* Filters */}
            <div className="bg-slate-800 p-4 rounded-2xl border border-slate-700 flex flex-col md:flex-row items-center justify-between gap-3">
              <div className="relative w-full md:w-80">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Tìm học viên, email, tiêu đề..."
                  value={subSearch}
                  onChange={(e) => setSubSearch(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="flex items-center gap-2 w-full md:w-auto overflow-x-auto">
                <button
                  onClick={() => setSubStatusFilter('all')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap cursor-pointer ${
                    subStatusFilter === 'all' ? 'bg-slate-700 text-white' : 'bg-slate-900 text-slate-400'
                  }`}
                >
                  Tất cả ({submissions.length})
                </button>
                <button
                  onClick={() => setSubStatusFilter('pending')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap cursor-pointer ${
                    subStatusFilter === 'pending' ? 'bg-amber-500 text-slate-900' : 'bg-slate-900 text-amber-400'
                  }`}
                >
                  Chờ duyệt ({pendingCount})
                </button>
                <button
                  onClick={() => setSubStatusFilter('approved')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap cursor-pointer ${
                    subStatusFilter === 'approved' ? 'bg-emerald-600 text-white' : 'bg-slate-900 text-emerald-400'
                  }`}
                >
                  Đã duyệt ({approvedCount})
                </button>
                <button
                  onClick={() => setSubStatusFilter('rejected')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap cursor-pointer ${
                    subStatusFilter === 'rejected' ? 'bg-rose-600 text-white' : 'bg-slate-900 text-rose-400'
                  }`}
                >
                  Từ chối ({rejectedCount})
                </button>
              </div>
            </div>

            {/* Submissions Table */}
            <div className="bg-slate-800 border border-slate-700 rounded-3xl overflow-hidden shadow-xl">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-slate-300">
                  <thead className="bg-slate-900/80 text-[11px] uppercase tracking-wider text-slate-400 border-b border-slate-700">
                    <tr>
                      <th className="py-3.5 px-4 font-bold">Học viên</th>
                      <th className="py-3.5 px-4 font-bold">Tiêu đề bài nộp</th>
                      <th className="py-3.5 px-4 font-bold">Đính kèm</th>
                      <th className="py-3.5 px-4 font-bold">Trạng thái</th>
                      <th className="py-3.5 px-4 font-bold">Ngày nộp</th>
                      <th className="py-3.5 px-4 font-bold text-right">Hành động</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-700/60">
                    {filteredSubmissions.length === 0 ? (
                      <tr>
                        <td colSpan={6} className="py-12 text-center text-slate-400">
                          Không tìm thấy bài nộp nào phù hợp với bộ lọc.
                        </td>
                      </tr>
                    ) : (
                      filteredSubmissions.map((sub) => (
                        <tr key={sub.id} className="hover:bg-slate-700/40 transition-colors">
                          <td className="py-3.5 px-4">
                            <p className="font-bold text-white">{sub.user_name}</p>
                            <p className="text-[11px] text-slate-400">{sub.user_email}</p>
                          </td>
                          <td className="py-3.5 px-4 max-w-xs">
                            <p className="font-semibold text-slate-200 truncate" title={sub.title}>
                              {sub.title}
                            </p>
                            <p className="text-[11px] text-slate-400 truncate mt-0.5">
                              {sub.content}
                            </p>
                          </td>
                          <td className="py-3.5 px-4">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              {sub.link_url && (
                                <a
                                  href={sub.link_url}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="p-1.5 bg-slate-700 hover:bg-slate-600 rounded text-emerald-400"
                                  title="Mở liên kết bài nộp"
                                >
                                  <ExternalLink className="w-3.5 h-3.5" />
                                </a>
                              )}
                              {sub.file && (
                                <button
                                  onClick={() => downloadFile(sub)}
                                  className="p-1.5 bg-slate-700 hover:bg-slate-600 rounded text-emerald-400 flex items-center gap-1 cursor-pointer"
                                  title={`Tải tệp: ${sub.file.name}`}
                                >
                                  <FileDown className="w-3.5 h-3.5" />
                                </button>
                              )}
                            </div>
                          </td>
                          <td className="py-3.5 px-4">
                            {sub.status === 'approved' && (
                              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                                Đã duyệt
                              </span>
                            )}
                            {sub.status === 'rejected' && (
                              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-rose-500/20 text-rose-300 border border-rose-500/30">
                                Từ chối
                              </span>
                            )}
                            {sub.status === 'pending' && (
                              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                                Chờ duyệt
                              </span>
                            )}
                          </td>
                          <td className="py-3.5 px-4 text-[11px] text-slate-400 whitespace-nowrap">
                            {new Date(sub.created_at).toLocaleDateString('vi-VN')}
                          </td>
                          <td className="py-3.5 px-4 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              <button
                                onClick={() => setSelectedSub(sub)}
                                title="Xem chi tiết bài"
                                className="p-1.5 bg-slate-700 hover:bg-slate-600 text-slate-300 rounded-lg transition-colors cursor-pointer"
                              >
                                <Eye className="w-3.5 h-3.5" />
                              </button>

                              <button
                                onClick={() => setApprovingSub(sub)}
                                title="Phê duyệt bài nộp"
                                className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg transition-colors cursor-pointer text-[11px]"
                              >
                                Duyệt
                              </button>

                              <button
                                onClick={() => {
                                  setRejectingSub(sub);
                                  setRejectionReason('');
                                  setRejectionError(null);
                                }}
                                title="Từ chối (bắt buộc ghi lý do)"
                                className="px-2.5 py-1 bg-rose-600/80 hover:bg-rose-600 text-white font-bold rounded-lg transition-colors cursor-pointer text-[11px]"
                              >
                                Từ chối
                              </button>

                              {/* Delete button using Custom in-app dialog */}
                              <button
                                onClick={() => requestDeleteSubmission(sub)}
                                title="Xóa bài nộp này"
                                className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-rose-950/40 rounded-lg transition-colors cursor-pointer"
                              >
                                <Trash2 className="w-4 h-4 text-rose-400" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: USER MANAGEMENT & PASSWORDS */}
        {activeTab === 'users' && (
          <div className="space-y-4">
            <div className="bg-slate-800 p-4 rounded-2xl border border-slate-700 flex flex-col sm:flex-row items-center justify-between gap-3">
              <div className="relative w-full sm:w-96">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Tìm theo tên học viên, email, mã tài khoản..."
                  value={userSearch}
                  onChange={(e) => setUserSearch(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="text-xs text-slate-300 flex items-center gap-2">
                <span>Tổng số tài khoản:</span>
                <span className="font-extrabold text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded-full border border-emerald-500/40 font-mono">
                  {users.length}
                </span>
              </div>
            </div>

            <div className="bg-slate-800 border border-slate-700 rounded-3xl overflow-hidden shadow-xl">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-slate-300">
                  <thead className="bg-slate-900/80 text-[11px] uppercase tracking-wider text-slate-400 border-b border-slate-700">
                    <tr>
                      <th className="py-3.5 px-4 font-bold">Mã / Thông tin cá nhân</th>
                      <th className="py-3.5 px-4 font-bold">Email</th>
                      <th className="py-3.5 px-4 font-bold text-emerald-400">
                        <span className="flex items-center gap-1">
                          <Key className="w-3.5 h-3.5" />
                          Mật khẩu đăng ký
                        </span>
                      </th>
                      <th className="py-3.5 px-4 font-bold">Vai trò</th>
                      <th className="py-3.5 px-4 font-bold">Bài đã nộp</th>
                      <th className="py-3.5 px-4 font-bold">Trạng thái</th>
                      <th className="py-3.5 px-4 font-bold">Ngày đăng ký</th>
                      <th className="py-3.5 px-4 font-bold text-right">Quản trị tài khoản</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-700/60">
                    {filteredUsers.map((u) => {
                      const isPwdVisible = Boolean(showPasswordMap[u.id]);
                      const pwd = u.password || '123456';

                      return (
                        <tr key={u.id} className="hover:bg-slate-700/40 transition-colors">
                          <td className="py-3.5 px-4">
                            <p className="font-bold text-white flex items-center gap-1.5">
                              {u.full_name}
                              {u.id === currentUser.id && (
                                <span className="text-[10px] text-emerald-400 bg-emerald-950/60 px-1.5 py-0.5 rounded border border-emerald-500/40">
                                  Bạn
                                </span>
                              )}
                            </p>
                            <p className="text-[10px] text-slate-500 font-mono mt-0.5">
                              ID: {u.id}
                            </p>
                          </td>

                          <td className="py-3.5 px-4 font-mono text-slate-200">
                            {u.email}
                          </td>

                          {/* Password Column with show/hide and copy */}
                          <td className="py-3.5 px-4">
                            <div className="flex items-center gap-1.5 bg-slate-900/90 px-2.5 py-1.5 rounded-xl border border-slate-700 font-mono text-xs w-fit">
                              <span className="text-emerald-300 font-bold min-w-[70px]">
                                {isPwdVisible ? pwd : '••••••••'}
                              </span>
                              <button
                                type="button"
                                onClick={() => toggleShowPassword(u.id)}
                                className="p-1 text-slate-400 hover:text-white transition-colors cursor-pointer"
                                title={isPwdVisible ? 'Ẩn mật khẩu' : 'Hiển thị mật khẩu'}
                              >
                                {isPwdVisible ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                              </button>
                              <button
                                type="button"
                                onClick={() => copyToClipboard(pwd, 'mật khẩu')}
                                className="p-1 text-slate-400 hover:text-emerald-400 transition-colors cursor-pointer"
                                title="Sao chép mật khẩu"
                              >
                                <Copy className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>

                          <td className="py-3.5 px-4">
                            <span
                              className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                                u.role === 'admin'
                                  ? 'bg-teal-500/20 text-teal-300 border border-teal-500/40'
                                  : 'bg-slate-700 text-slate-300'
                              }`}
                            >
                              {u.role === 'admin' ? 'Quản trị viên' : 'Học viên'}
                            </span>
                          </td>

                          <td className="py-3.5 px-4 font-mono font-bold text-slate-200">
                            {u.submissions_count || 0} bài
                          </td>

                          <td className="py-3.5 px-4">
                            {u.is_locked ? (
                              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-rose-500/20 text-rose-300 border border-rose-500/30">
                                <Lock className="w-3 h-3 text-rose-400" />
                                Đã bị khóa
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                                <UserCheck className="w-3 h-3 text-emerald-400" />
                                Hoạt động
                              </span>
                            )}
                          </td>

                          <td className="py-3.5 px-4 text-[11px] text-slate-400 whitespace-nowrap">
                            {new Date(u.created_at).toLocaleDateString('vi-VN')}
                          </td>

                          <td className="py-3.5 px-4 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              {/* View Full Info */}
                              <button
                                onClick={() => setSelectedUserDetail(u)}
                                title="Xem toàn bộ thông tin tài khoản"
                                className="p-1.5 bg-slate-700 hover:bg-slate-600 text-slate-200 rounded-lg transition-colors cursor-pointer"
                              >
                                <Info className="w-3.5 h-3.5" />
                              </button>

                              {/* Toggle Lock / Unlock */}
                              <button
                                onClick={() => requestToggleLockUser(u)}
                                title={u.is_locked ? 'Mở khóa tài khoản' : 'Khóa tài khoản'}
                                className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                                  u.is_locked
                                    ? 'bg-emerald-600/20 text-emerald-300 hover:bg-emerald-600 hover:text-white'
                                    : 'bg-amber-500/20 text-amber-300 hover:bg-amber-600 hover:text-white'
                                }`}
                              >
                                {u.is_locked ? <Unlock className="w-3.5 h-3.5" /> : <Lock className="w-3.5 h-3.5" />}
                              </button>

                              {/* Toggle Role */}
                              {u.id !== currentUser.id && (
                                <button
                                  onClick={() => handleToggleRole(u)}
                                  title={u.role === 'admin' ? 'Chuyển về Học viên' : 'Thăng cấp thành Admin'}
                                  className="p-1.5 bg-slate-700 hover:bg-slate-600 text-slate-300 rounded-lg transition-colors cursor-pointer"
                                >
                                  <ShieldCheck className="w-3.5 h-3.5" />
                                </button>
                              )}

                              {/* Delete User via Custom In-App Modal */}
                              {u.id !== currentUser.id && (
                                <button
                                  onClick={() => requestDeleteUser(u)}
                                  title="Xóa tài khoản này"
                                  className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-rose-950/40 rounded-lg transition-colors cursor-pointer"
                                >
                                  <Trash2 className="w-4 h-4 text-rose-400" />
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 5: LUCKY GIFTS MANAGEMENT */}
        {activeTab === 'gifts' && (
          <div className="space-y-6">
            {/* Header info & actions */}
            <div className="bg-slate-800 p-5 rounded-3xl border border-slate-700 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/30">
                  <Gift className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white flex items-center gap-2">
                    Cấu Hình Hộp Quà May Mắn & Tỉ Lệ Tiền Thưởng
                  </h3>
                  <p className="text-xs text-slate-400">
                    Chỉnh sửa tên phần quà, số tiền, tỉ lệ trúng (%) và bật/tắt các món quà thành viên có thể nhận được
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 w-full md:w-auto">
                <button
                  onClick={handleResetGifts}
                  className="px-3.5 py-2 rounded-xl bg-slate-700 hover:bg-slate-600 text-slate-300 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                  title="Khôi phục 5 quà mẫu ban đầu"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Khôi phục mẫu</span>
                </button>

                <button
                  onClick={handleOpenAddGift}
                  className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold flex items-center gap-1.5 transition-all shadow-md cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>Thêm phần quà mới</span>
                </button>
              </div>
            </div>

            {/* Quick stats row */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <div className="p-4 bg-slate-800 rounded-2xl border border-slate-700">
                <span className="text-xs text-slate-400">Tổng số phần quà</span>
                <p className="text-2xl font-bold text-white mt-1">{luckyGifts.length}</p>
              </div>

              <div className="p-4 bg-slate-800 rounded-2xl border border-emerald-500/30">
                <span className="text-xs text-emerald-400 font-semibold">Đang BẬT (Có thể trúng)</span>
                <p className="text-2xl font-bold text-emerald-400 mt-1">
                  {luckyGifts.filter((g) => g.is_active).length}
                </p>
              </div>

              <div className="p-4 bg-slate-800 rounded-2xl border border-slate-700">
                <span className="text-xs text-slate-400">Đã TẮT (Không xuất hiện)</span>
                <p className="text-2xl font-bold text-slate-400 mt-1">
                  {luckyGifts.filter((g) => !g.is_active).length}
                </p>
              </div>

              <div className="p-4 bg-slate-800 rounded-2xl border border-amber-500/30">
                <span className="text-xs text-amber-400 font-semibold">Tổng tỉ lệ hoạt động</span>
                <p className="text-2xl font-bold text-amber-400 mt-1">
                  {luckyGifts.filter((g) => g.is_active).reduce((sum, g) => sum + g.probability, 0)}%
                </p>
              </div>
            </div>

            {/* Gifts Table */}
            <div className="bg-slate-800 border border-slate-700 rounded-3xl overflow-hidden shadow-xl">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-slate-300">
                  <thead className="bg-slate-900/80 text-[11px] uppercase tracking-wider text-slate-400 border-b border-slate-700">
                    <tr>
                      <th className="py-3.5 px-4 font-bold">Tên phần quà</th>
                      <th className="py-3.5 px-4 font-bold">Số tiền thưởng</th>
                      <th className="py-3.5 px-4 font-bold">Tỉ lệ trúng (%)</th>
                      <th className="py-3.5 px-4 font-bold">Trạng thái (Bật/Tắt)</th>
                      <th className="py-3.5 px-4 font-bold">Lời chúc / Mô tả</th>
                      <th className="py-3.5 px-4 font-bold text-right">Thao tác</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-700/60">
                    {luckyGifts.length === 0 ? (
                      <tr>
                        <td colSpan={6} className="py-12 text-center text-slate-400">
                          Chưa có phần quà nào. Hãy bấm "Thêm phần quà mới" để tạo quà cho học viên.
                        </td>
                      </tr>
                    ) : (
                      luckyGifts.map((gift) => (
                        <tr key={gift.id} className="hover:bg-slate-700/40 transition-colors">
                          <td className="py-3.5 px-4">
                            <div className="flex items-center gap-2.5">
                              <div className={`w-8 h-8 rounded-xl flex items-center justify-center font-bold text-xs ${
                                gift.is_active ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40' : 'bg-slate-700 text-slate-400'
                              }`}>
                                <Gift className="w-4 h-4" />
                              </div>
                              <span className="font-bold text-white text-sm">{gift.name}</span>
                            </div>
                          </td>

                          <td className="py-3.5 px-4">
                            <span className="font-mono text-emerald-400 font-bold text-sm">
                              {new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(gift.amount)}
                            </span>
                          </td>

                          <td className="py-3.5 px-4">
                            <div className="space-y-1 w-32">
                              <div className="flex justify-between items-center text-[11px]">
                                <span className="font-bold text-amber-300">{gift.probability}%</span>
                              </div>
                              <div className="w-full bg-slate-900 rounded-full h-1.5 overflow-hidden">
                                <div
                                  className={`h-1.5 rounded-full ${gift.is_active ? 'bg-amber-400' : 'bg-slate-600'}`}
                                  style={{ width: `${Math.min(100, gift.probability)}%` }}
                                />
                              </div>
                            </div>
                          </td>

                          <td className="py-3.5 px-4">
                            <button
                              onClick={() => handleToggleGift(gift)}
                              className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-all ${
                                gift.is_active
                                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 hover:bg-emerald-500/30'
                                  : 'bg-slate-700/80 text-slate-400 border border-slate-600 hover:bg-slate-700'
                              }`}
                              title={gift.is_active ? 'Bấm để TẮT quà này (sẽ không thể nhận được)' : 'Bấm để BẬT quà này (thành viên có thể nhận được)'}
                            >
                              <span className={`w-2 h-2 rounded-full ${gift.is_active ? 'bg-emerald-400 animate-pulse' : 'bg-slate-500'}`} />
                              <span>{gift.is_active ? 'BẬT (Nhận được)' : 'TẮT (Đã khóa)'}</span>
                            </button>
                          </td>

                          <td className="py-3.5 px-4 max-w-xs text-slate-400 truncate" title={gift.description}>
                            {gift.description || '—'}
                          </td>

                          <td className="py-3.5 px-4 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              <button
                                onClick={() => handleOpenEditGift(gift)}
                                className="p-2 bg-slate-700 hover:bg-slate-600 text-slate-200 rounded-xl cursor-pointer transition-colors"
                                title="Chỉnh sửa tên và tỉ lệ quà"
                              >
                                <Edit className="w-3.5 h-3.5 text-amber-400" />
                              </button>

                              <button
                                onClick={() => requestDeleteGift(gift)}
                                className="p-2 bg-slate-700 hover:bg-rose-950/60 text-slate-400 hover:text-rose-400 rounded-xl cursor-pointer transition-colors"
                                title="Xóa phần quà này"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: SETTINGS & MAINTENANCE */}
        {activeTab === 'settings' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Maintenance Toggle Card */}
              <div className="bg-slate-800 border border-slate-700 rounded-3xl p-6 space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-2xl flex items-center justify-center ${
                      settings.is_maintenance ? 'bg-amber-500/20 text-amber-400' : 'bg-emerald-500/20 text-emerald-400'
                    }`}>
                      <Wrench className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="font-bold text-white text-base">Chế Độ Bảo Trì Hệ Thống</h3>
                      <p className="text-xs text-slate-400">
                        Khi bật, học viên vào trang nộp bài sẽ thấy thông báo tạm ngừng nhận bài.
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={handleToggleMaintenance}
                    className={`w-14 h-8 flex items-center rounded-full p-1 cursor-pointer transition-colors ${
                      settings.is_maintenance ? 'bg-amber-500' : 'bg-slate-700'
                    }`}
                  >
                    <div
                      className={`bg-white w-6 h-6 rounded-full shadow-md transform transition-transform ${
                        settings.is_maintenance ? 'translate-x-6' : 'translate-x-0'
                      }`}
                    />
                  </button>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    Nội dung thông báo hiển thị cho học viên khi bảo trì:
                  </label>
                  <textarea
                    rows={3}
                    value={settings.maintenance_message}
                    onChange={(e) => setSettings({ ...settings, maintenance_message: e.target.value })}
                    className="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-emerald-500"
                  />
                  <button
                    onClick={() => handleSaveMaintenanceMessage(settings.maintenance_message)}
                    className="mt-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition-all cursor-pointer"
                  >
                    Lưu thông điệp bảo trì
                  </button>
                </div>
              </div>

              {/* Upload Limits & Security Configuration */}
              <div className="bg-slate-800 border border-slate-700 rounded-3xl p-6 space-y-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-teal-500/20 text-teal-400 flex items-center justify-center">
                    <ShieldCheck className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-bold text-white text-base">Cấu Hình Lưu Trữ Tệp (Storage)</h3>
                    <p className="text-xs text-slate-400">Chính sách bảo mật Private Storage và định dạng tệp</p>
                  </div>
                </div>

                <div className="space-y-3 text-xs">
                  <div className="p-3 bg-slate-900/70 rounded-xl border border-slate-700 flex justify-between items-center">
                    <span className="text-slate-400">Giới hạn dung lượng tệp</span>
                    <span className="font-bold text-emerald-400">{settings.max_file_size_mb} MB / tệp</span>
                  </div>

                  <div className="p-3 bg-slate-900/70 rounded-xl border border-slate-700 flex justify-between items-center">
                    <span className="text-slate-400">Định dạng hỗ trợ</span>
                    <span className="font-mono text-slate-300 uppercase">{settings.allowed_file_types}</span>
                  </div>

                  <div className="p-3 bg-slate-900/70 rounded-xl border border-slate-700 flex justify-between items-center">
                    <span className="text-slate-400">Phân quyền Storage</span>
                    <span className="font-bold text-emerald-400">Private Bucket (RLS)</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Supabase Cloud Connection & SQL Schema Tool (ADMIN ONLY) */}
            <div className="bg-slate-800 border border-slate-700 rounded-3xl p-6 space-y-5 shadow-xl">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-700/80 pb-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30">
                    <Database className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-bold text-white text-base flex items-center gap-2">
                      Cấu Hình Kết Nối Supabase Cloud & RLS
                      <span className="text-[10px] font-mono font-bold bg-slate-900 text-slate-400 px-2 py-0.5 rounded border border-slate-700">
                        Admin Only
                      </span>
                    </h3>
                    <p className="text-xs text-slate-400">
                      Thiết lập bảo mật riêng cho quản trị viên tại /#adminbas (hoàn toàn ẩn khỏi trang học viên)
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <span className={`px-3 py-1 rounded-full text-xs font-bold border flex items-center gap-1.5 ${
                    supabaseConfigured
                      ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                      : 'bg-teal-500/20 text-teal-300 border-teal-500/40'
                  }`}>
                    <span className={`w-2 h-2 rounded-full ${supabaseConfigured ? 'bg-emerald-400 animate-pulse' : 'bg-teal-400'}`} />
                    <span>{supabaseConfigured ? 'Supabase Cloud: Đã kết nối' : 'Local Storage Engine: Đang hoạt động'}</span>
                  </span>
                </div>
              </div>

              {/* Form Config */}
              <form onSubmit={handleSaveSupabase} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                      Supabase Project URL
                    </label>
                    <input
                      type="url"
                      placeholder="https://xyzcompany.supabase.co"
                      value={supabaseUrl}
                      onChange={(e) => setSupabaseUrl(e.target.value)}
                      className="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-emerald-500"
                    />
                    <p className="text-[11px] text-slate-500 mt-1">
                      Lấy từ Supabase Dashboard &gt; Settings &gt; API &gt; Project URL.
                    </p>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                      Supabase Anon Public API Key
                    </label>
                    <input
                      type="password"
                      placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
                      value={supabaseAnonKey}
                      onChange={(e) => setSupabaseAnonKey(e.target.value)}
                      className="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-emerald-500 font-mono"
                    />
                    <p className="text-[11px] text-slate-500 mt-1">
                      Chỉ dùng Anon Public Key (tuyệt đối không dùng service_role key ở frontend).
                    </p>
                  </div>
                </div>

                <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
                  <div className="flex items-center gap-2">
                    <button
                      type="submit"
                      className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold shadow-md cursor-pointer transition-all flex items-center gap-1.5"
                    >
                      <Database className="w-4 h-4" />
                      <span>Lưu & Kết nối Supabase Cloud</span>
                    </button>

                    <button
                      type="button"
                      onClick={handleClearSupabase}
                      className="px-4 py-2.5 bg-slate-700 hover:bg-slate-600 text-slate-300 rounded-xl text-xs font-semibold cursor-pointer transition-colors"
                    >
                      Dùng Local Engine
                    </button>
                  </div>

                  <button
                    type="button"
                    onClick={() => setShowSqlSchema(!showSqlSchema)}
                    className="px-4 py-2 bg-slate-900 hover:bg-slate-700 border border-slate-700 text-emerald-400 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5"
                  >
                    <FileCode className="w-4 h-4" />
                    <span>{showSqlSchema ? 'Ẩn mã SQL Supabase' : 'Xem & Sao chép mã SQL Schema & RLS'}</span>
                  </button>
                </div>
              </form>

              {/* SQL Schema Inspector Drawer */}
              {showSqlSchema && (
                <div className="p-4 bg-slate-950 rounded-2xl border border-slate-700/80 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold">
                      <FileCode className="w-4 h-4" />
                      <span>Mã SQL DDL, RLS Policies & Private Storage Bucket cho Supabase</span>
                    </div>

                    <button
                      type="button"
                      onClick={handleCopySqlSchema}
                      className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
                    >
                      {copiedSql ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedSql ? 'Đã sao chép!' : 'Sao chép toàn bộ SQL'}</span>
                    </button>
                  </div>

                  <p className="text-[11px] text-slate-400">
                    Dán đoạn mã này vào <strong>SQL Editor</strong> trên Supabase Dashboard để tự động khởi tạo các bảng <code className="text-emerald-300">profiles</code>, <code className="text-emerald-300">submissions</code>, <code className="text-emerald-300">system_settings</code>, các chính sách <strong>RLS</strong> và Private Storage Bucket.
                  </p>

                  <pre className="p-3 bg-slate-900 rounded-xl text-[11px] text-slate-300 font-mono overflow-x-auto max-h-60 border border-slate-800 leading-relaxed">
{`-- 1. BẢNG PROFILES & RLS
create table if not exists public.profiles (
  id uuid references auth.users on delete cascade primary key,
  email text not null,
  full_name text not null,
  role text not null default 'user' check (role in ('user', 'admin')),
  is_locked boolean not null default false,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);
alter table public.profiles enable row level security;

-- 2. BẢNG SUBMISSIONS & RLS
create table if not exists public.submissions (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references public.profiles(id) on delete cascade not null,
  user_name text not null,
  user_email text not null,
  title text not null,
  content text not null,
  link_url text,
  file_name text,
  file_url text,
  file_path text,
  status text not null default 'pending' check (status in ('pending', 'approved', 'rejected')),
  admin_feedback text,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);
alter table public.submissions enable row level security;

-- 3. PRIVATE STORAGE BUCKET
insert into storage.buckets (id, name, public) values ('submissions', 'submissions', false) on conflict do update set public = false;`}
                  </pre>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* USER DETAIL MODAL: Full registered information */}
      {selectedUserDetail && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="w-full max-w-xl bg-slate-800 border border-slate-700 rounded-3xl p-6 shadow-2xl space-y-5 my-8">
            <div className="flex items-start justify-between border-b border-slate-700 pb-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-lg font-bold border border-emerald-500/30">
                  {selectedUserDetail.full_name?.charAt(0).toUpperCase()}
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white">{selectedUserDetail.full_name}</h3>
                  <p className="text-xs text-slate-400">{selectedUserDetail.email}</p>
                </div>
              </div>
              <button
                onClick={() => setSelectedUserDetail(null)}
                className="p-2 text-slate-400 hover:text-white rounded-full bg-slate-700 hover:bg-slate-600"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="p-3.5 bg-slate-900/80 rounded-2xl border border-slate-700/80 flex justify-between items-center">
                <span className="text-slate-400">Mã định danh User ID:</span>
                <span className="font-mono text-emerald-400 select-all font-bold">{selectedUserDetail.id}</span>
              </div>

              <div className="p-3.5 bg-slate-900/80 rounded-2xl border border-slate-700/80 flex justify-between items-center">
                <span className="text-slate-400">Mật khẩu đăng nhập:</span>
                <div className="flex items-center gap-2">
                  <span className="font-mono text-emerald-300 font-bold bg-slate-950 px-2.5 py-1 rounded-lg border border-slate-800">
                    {selectedUserDetail.password || '123456'}
                  </span>
                  <button
                    onClick={() => copyToClipboard(selectedUserDetail.password || '123456', 'mật khẩu')}
                    className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg cursor-pointer"
                    title="Sao chép mật khẩu"
                  >
                    <Copy className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              <div className="p-3.5 bg-slate-900/80 rounded-2xl border border-slate-700/80 flex justify-between items-center">
                <span className="text-slate-400">Vai trò trong hệ thống:</span>
                <span className="font-bold text-slate-200">
                  {selectedUserDetail.role === 'admin' ? 'Quản trị viên (Admin)' : 'Học viên (User)'}
                </span>
              </div>

              <div className="p-3.5 bg-slate-900/80 rounded-2xl border border-slate-700/80 flex justify-between items-center">
                <span className="text-slate-400">Trạng thái khóa:</span>
                <span className={`font-bold ${selectedUserDetail.is_locked ? 'text-rose-400' : 'text-emerald-400'}`}>
                  {selectedUserDetail.is_locked ? 'Bị khóa' : 'Đang hoạt động bình thường'}
                </span>
              </div>

              <div className="p-3.5 bg-slate-900/80 rounded-2xl border border-slate-700/80 flex justify-between items-center">
                <span className="text-slate-400">Ngày tạo tài khoản:</span>
                <span className="font-semibold text-slate-300">
                  {new Date(selectedUserDetail.created_at).toLocaleString('vi-VN')}
                </span>
              </div>

              <div className="p-3.5 bg-slate-900/80 rounded-2xl border border-slate-700/80 flex justify-between items-center">
                <span className="text-slate-400">Số bài tập đã gửi:</span>
                <span className="font-bold text-emerald-400 font-mono">
                  {selectedUserDetail.submissions_count || 0} bài
                </span>
              </div>
            </div>

            <div className="flex items-center justify-between pt-3 border-t border-slate-700">
              <button
                onClick={() => {
                  setSelectedUserDetail(null);
                  setActiveTab('submissions');
                  setSubSearch(selectedUserDetail.email);
                }}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition-all cursor-pointer"
              >
                Xem các bài nộp của học viên này →
              </button>

              <button
                onClick={() => setSelectedUserDetail(null)}
                className="px-5 py-2 bg-slate-700 hover:bg-slate-600 text-slate-200 rounded-xl text-xs font-bold"
              >
                Đóng
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CUSTOM IN-APP CONFIRMATION DIALOG (Never gets blocked by iframe) */}
      {confirmDialog && confirmDialog.isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-xs p-4 animate-fade-in">
          <div className="w-full max-w-md bg-slate-800 border border-slate-700 rounded-3xl p-6 shadow-2xl space-y-4">
            <div className="flex items-center gap-3">
              <div className={`p-3 rounded-2xl ${confirmDialog.isDangerous ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30' : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'}`}>
                <AlertTriangle className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-bold text-white text-lg tracking-tight">
                  {confirmDialog.title}
                </h3>
                <p className="text-xs text-slate-400">Xác nhận thao tác quản trị</p>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed bg-slate-900/60 p-3.5 rounded-2xl border border-slate-700/60">
              {confirmDialog.message}
            </p>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                onClick={() => setConfirmDialog(null)}
                className="px-4 py-2 bg-slate-700 hover:bg-slate-600 text-slate-300 rounded-xl text-xs font-bold cursor-pointer"
              >
                Hủy bỏ
              </button>
              <button
                onClick={confirmDialog.onConfirm}
                className={`px-5 py-2 text-white rounded-xl text-xs font-bold shadow-lg cursor-pointer ${
                  confirmDialog.isDangerous
                    ? 'bg-rose-600 hover:bg-rose-500 shadow-rose-950'
                    : 'bg-emerald-600 hover:bg-emerald-500 shadow-emerald-950'
                }`}
              >
                {confirmDialog.confirmText || 'Xác nhận'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* REJECT MODAL: Mandatory Reason */}
      {rejectingSub && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4">
          <div className="w-full max-w-md bg-slate-800 border border-rose-500/40 rounded-3xl p-6 shadow-2xl space-y-4">
            <div className="flex items-center gap-3 text-rose-400">
              <div className="p-2.5 rounded-xl bg-rose-500/20">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-bold text-white text-lg">Từ Chối Bài Nộp</h3>
                <p className="text-xs text-slate-400">Học viên: {rejectingSub.user_name}</p>
              </div>
            </div>

            <p className="text-xs text-slate-300">
              Tiêu đề bài: <span className="font-semibold text-white">{rejectingSub.title}</span>
            </p>

            {rejectionError && (
              <div className="p-3 bg-rose-500/20 border border-rose-500/50 rounded-xl text-xs text-rose-300">
                {rejectionError}
              </div>
            )}

            <div>
              <label className="block text-xs font-bold text-slate-200 mb-1.5">
                Lý do từ chối cụ thể <span className="text-rose-400">* (Bắt buộc)</span>:
              </label>
              <textarea
                rows={4}
                required
                placeholder="Ví dụ: Bài nộp còn thiếu file mã nguồn hoặc liên kết không truy cập được. Vui lòng cập nhật quyền xem và nộp lại..."
                value={rejectionReason}
                onChange={(e) => {
                  setRejectionReason(e.target.value);
                  setRejectionError(null);
                }}
                className="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-rose-500 focus:ring-1 focus:ring-rose-500 leading-relaxed placeholder-slate-500"
              />
              <p className="text-[11px] text-slate-400 mt-1">
                Lý do này sẽ hiển thị trực tiếp cho học viên trong danh sách bài nộp của họ để họ biết và sửa đổi.
              </p>
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                onClick={() => setRejectingSub(null)}
                className="px-4 py-2 bg-slate-700 hover:bg-slate-600 text-slate-300 rounded-xl text-xs font-bold cursor-pointer"
              >
                Hủy bỏ
              </button>
              <button
                onClick={handleConfirmReject}
                className="px-5 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-rose-950 cursor-pointer"
              >
                Xác nhận Từ Chối
              </button>
            </div>
          </div>
        </div>
      )}

      {/* APPROVE MODAL */}
      {approvingSub && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4">
          <div className="w-full max-w-md bg-slate-800 border border-emerald-500/40 rounded-3xl p-6 shadow-2xl space-y-4">
            <div className="flex items-center gap-3 text-emerald-400">
              <div className="p-2.5 rounded-xl bg-emerald-500/20">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-bold text-white text-lg">Phê Duyệt Bài Nộp</h3>
                <p className="text-xs text-slate-400">Học viên: {approvingSub.user_name}</p>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-200 mb-1.5">
                Nhận xét / Đánh giá của Quản trị viên (Tùy chọn):
              </label>
              <textarea
                rows={3}
                value={approveFeedback}
                onChange={(e) => setApproveFeedback(e.target.value)}
                className="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-emerald-500 leading-relaxed"
              />
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                onClick={() => setApprovingSub(null)}
                className="px-4 py-2 bg-slate-700 hover:bg-slate-600 text-slate-300 rounded-xl text-xs font-bold cursor-pointer"
              >
                Hủy bỏ
              </button>
              <button
                onClick={handleConfirmApprove}
                className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-emerald-950 cursor-pointer"
              >
                Xác nhận Phê Duyệt
              </button>
            </div>
          </div>
        </div>
      )}

      {/* VIEW DETAILS MODAL */}
      {selectedSub && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="w-full max-w-2xl bg-slate-800 border border-slate-700 rounded-3xl p-6 shadow-2xl space-y-5 my-8">
            <div className="flex items-start justify-between gap-4 border-b border-slate-700 pb-4">
              <div>
                <span className="text-[11px] font-mono text-emerald-400">Mã: {selectedSub.id}</span>
                <h3 className="text-xl font-bold text-white mt-1">{selectedSub.title}</h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Nộp bởi: <span className="text-slate-200 font-semibold">{selectedSub.user_name}</span> ({selectedSub.user_email})
                </p>
              </div>
              <button
                onClick={() => setSelectedSub(null)}
                className="p-2 text-slate-400 hover:text-white rounded-full bg-slate-700 hover:bg-slate-600"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4 text-xs">
              <div>
                <h4 className="font-bold text-slate-400 uppercase tracking-wider mb-1.5">
                  Nội dung bài làm
                </h4>
                <div className="p-4 bg-slate-900 rounded-2xl border border-slate-700/80 text-slate-200 whitespace-pre-wrap leading-relaxed">
                  {selectedSub.content}
                </div>
              </div>

              {selectedSub.link_url && (
                <div>
                  <h4 className="font-bold text-slate-400 uppercase tracking-wider mb-1.5">
                    Liên kết dự án
                  </h4>
                  <a
                    href={selectedSub.link_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-3 bg-slate-900 rounded-xl border border-slate-700 flex items-center justify-between text-emerald-400 hover:text-emerald-300"
                  >
                    <span className="truncate">{selectedSub.link_url}</span>
                    <ExternalLink className="w-4 h-4 shrink-0" />
                  </a>
                </div>
              )}

              {selectedSub.file && (
                <div>
                  <h4 className="font-bold text-slate-400 uppercase tracking-wider mb-1.5">
                    Tệp đính kèm (Admin toàn quyền quản lý & tải về)
                  </h4>
                  <div className="p-3 bg-slate-900 rounded-xl border border-slate-700 flex items-center justify-between">
                    <div>
                      <p className="font-bold text-white">{selectedSub.file.name}</p>
                      <p className="text-slate-400">
                        {(selectedSub.file.size / (1024 * 1024)).toFixed(2)} MB • {selectedSub.file.type}
                      </p>
                    </div>
                    <button
                      onClick={() => downloadFile(selectedSub)}
                      className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold flex items-center gap-1.5 cursor-pointer"
                    >
                      <FileDown className="w-4 h-4" />
                      Tải về
                    </button>
                  </div>
                </div>
              )}

              {selectedSub.admin_feedback && (
                <div className="p-4 bg-slate-900 rounded-2xl border border-slate-700 space-y-1">
                  <span className="font-bold text-slate-300">Ghi chú / Nhận xét hiện tại:</span>
                  <p className="text-slate-200">{selectedSub.admin_feedback}</p>
                </div>
              )}
            </div>

            <div className="flex justify-between items-center pt-2 border-t border-slate-700">
              <button
                onClick={() => {
                  requestDeleteSubmission(selectedSub);
                }}
                className="px-4 py-2 bg-rose-600/20 text-rose-300 hover:bg-rose-600 hover:text-white rounded-xl font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                Xóa bài nộp này
              </button>

              <button
                onClick={() => setSelectedSub(null)}
                className="px-5 py-2 bg-slate-700 hover:bg-slate-600 text-slate-200 rounded-xl font-bold text-xs"
              >
                Đóng
              </button>
            </div>
          </div>
        </div>
      )}

      {/* LUCKY GIFT ADD / EDIT MODAL */}
      {isGiftModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-xs p-4 animate-fade-in">
          <div className="w-full max-w-md bg-slate-800 border border-amber-500/40 rounded-3xl p-6 shadow-2xl space-y-4 text-left">
            <div className="flex items-center justify-between border-b border-slate-700 pb-3">
              <div className="flex items-center gap-2.5 text-amber-400">
                <Gift className="w-5 h-5" />
                <h3 className="font-bold text-white text-base">
                  {editingGift ? 'Chỉnh Sửa Phần Quà' : 'Thêm Phần Quà May Mắn Mới'}
                </h3>
              </div>
              <button
                onClick={() => setIsGiftModalOpen(false)}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg bg-slate-700"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveGiftSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Tên phần quà <span className="text-amber-400">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="Ví dụ: Lì xì 50.000đ May Mắn"
                  value={giftFormName}
                  onChange={(e) => setGiftFormName(e.target.value)}
                  className="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-amber-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    Số tiền thưởng (VNĐ)
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="1000"
                    required
                    value={giftFormAmount}
                    onChange={(e) => setGiftFormAmount(Number(e.target.value))}
                    className="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-amber-500 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    Tỉ lệ trúng (%) <span className="text-amber-400">*</span>
                  </label>
                  <input
                    type="number"
                    min="0"
                    max="100"
                    required
                    value={giftFormProb}
                    onChange={(e) => setGiftFormProb(Number(e.target.value))}
                    className="w-full px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-amber-500 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Lời chúc hiển thị khi mở trúng:
                </label>
                <textarea
                  rows={2}
                  placeholder="Ví dụ: Chúc bạn học tập xuất sắc và gặt hái nhiều thành công!"
                  value={giftFormDesc}
                  onChange={(e) => setGiftFormDesc(e.target.value)}
                  className="w-full px-4 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-amber-500"
                />
              </div>

              {/* Active Toggle in form */}
              <div className="p-3 bg-slate-900/80 rounded-xl border border-slate-700 flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-white block">Cho phép học viên nhận quà này</span>
                  <span className="text-[11px] text-slate-400">Nếu tắt, quà này sẽ không bao giờ xuất hiện khi mở hộp.</span>
                </div>
                <button
                  type="button"
                  onClick={() => setGiftFormActive(!giftFormActive)}
                  className={`w-12 h-6 flex items-center rounded-full p-1 cursor-pointer transition-colors ${
                    giftFormActive ? 'bg-emerald-500' : 'bg-slate-700'
                  }`}
                >
                  <div
                    className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${
                      giftFormActive ? 'translate-x-6' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>

              <div className="flex items-center justify-end gap-2.5 pt-2">
                <button
                  type="button"
                  onClick={() => setIsGiftModalOpen(false)}
                  className="px-4 py-2 bg-slate-700 hover:bg-slate-600 text-slate-300 rounded-xl text-xs font-semibold cursor-pointer"
                >
                  Hủy bỏ
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-xl text-xs font-bold shadow-md cursor-pointer transition-all"
                >
                  {editingGift ? 'Cập nhật quà' : 'Lưu phần quà'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
