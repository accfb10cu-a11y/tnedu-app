import { createClient, SupabaseClient } from '@supabase/supabase-js';

const STORAGE_KEY_URL = 'edusubmit_supabase_url';
const STORAGE_KEY_ANON = 'edusubmit_supabase_anon';

export const isValidSupabaseUrl = (url: string): boolean => {
  if (!url || typeof url !== 'string') return false;
  const trimmed = url.trim().toLowerCase();
  if (trimmed.includes('xyzcompany') || trimmed.includes('example.com') || trimmed.includes('placeholder')) {
    return false;
  }
  try {
    const parsed = new URL(trimmed);
    return Boolean(
      (parsed.protocol === 'https:' || parsed.protocol === 'http:') &&
      parsed.hostname &&
      parsed.hostname.length > 5
    );
  } catch {
    return false;
  }
};

export const getSupabaseConfig = () => {
  const envUrl = (import.meta as any).env?.VITE_SUPABASE_URL;
  const envKey = (import.meta as any).env?.VITE_SUPABASE_ANON_KEY;
  const localUrl = localStorage.getItem(STORAGE_KEY_URL);
  const localKey = localStorage.getItem(STORAGE_KEY_ANON);

  const url = (envUrl || localUrl || '').trim();
  const anonKey = (envKey || localKey || '').trim();

  // If local storage has invalid placeholder URL, clean it up
  if (localUrl && !isValidSupabaseUrl(localUrl)) {
    localStorage.removeItem(STORAGE_KEY_URL);
    localStorage.removeItem(STORAGE_KEY_ANON);
  }

  const isConfigured = Boolean(
    url &&
    anonKey &&
    anonKey.length > 20 &&
    isValidSupabaseUrl(url)
  );

  return { url, anonKey, isConfigured };
};

export const saveSupabaseConfig = (url: string, anonKey: string) => {
  const cleanUrl = url.trim();
  const cleanKey = anonKey.trim();

  if (isValidSupabaseUrl(cleanUrl) && cleanKey) {
    localStorage.setItem(STORAGE_KEY_URL, cleanUrl);
    localStorage.setItem(STORAGE_KEY_ANON, cleanKey);
  } else {
    localStorage.removeItem(STORAGE_KEY_URL);
    localStorage.removeItem(STORAGE_KEY_ANON);
  }
};

let cachedClient: SupabaseClient | null = null;
let lastUrl = '';
let lastKey = '';

export const getSupabaseClient = (): SupabaseClient | null => {
  const { url, anonKey, isConfigured } = getSupabaseConfig();
  if (!isConfigured) return null;

  if (cachedClient && lastUrl === url && lastKey === anonKey) {
    return cachedClient;
  }

  try {
    cachedClient = createClient(url, anonKey, {
      auth: {
        persistSession: true,
        autoRefreshToken: true,
      },
    });
    lastUrl = url;
    lastKey = anonKey;
    return cachedClient;
  } catch (err) {
    console.warn('Error initializing Supabase client, using local engine:', err);
    return null;
  }
};
